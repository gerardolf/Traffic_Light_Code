function [graph_points] = streetgrid_plot( dim, node_on, text_on )
%dim specifies number of horizontal/vertical (WE/NS) streets
%node_on and text_on determine if the nodes/labels will display (use 1 to
%display)

size = 65;
spec = ':k'; lw = 1;
m = dim(1); n = dim(2);

%I will be labelling points row-wise from top lane to bottom lane (bird's
%eye view) then column-wise from left lane to right lane

N = 4*m*n;
graph_points = zeros(N,2);
H = [0,10]; %these will form segments with which we construct the grid
V = [15,15];

xlim([0, 15*(n+1)-5]); ylim([0, 15*(m+1)]);
    
hold on
axis equal
for i = 1:m
    
    for j = 1:n
        
        %plot WE streets
        plot(H + (j-1)*15, V + 15*((m+1)-i)-10,spec,'LineWidth',lw);
        plot(H + (j-1)*15, V + 15*((m+1)-i)-15,spec,'LineWidth',lw);
        %plot WE end street (just shorter streets)
        plot(H + n*15, V + 15*((m+1)-i)-10,spec,'LineWidth',lw);
        plot(H + n*15, V + 15*((m+1)-i)-15,spec,'LineWidth',lw);
        %plot NS streets
        plot(V + (j-1)*15-5, H + 15*((m+1)-i)+5,spec,'LineWidth',lw);
        plot(V + (j-1)*15, H + 15*((m+1)-i)+5,spec,'LineWidth',lw);
        %plot NS end streets
        plot(V + (j-1)*15-5, H + 5,spec,'LineWidth',lw);
        plot(V + (j-1)*15, H + 5,spec,'LineWidth',lw);
        
        %finds vertices along the rows
        if (mod(i,2)~=0)
            x = mean(H + (j-1)*15);
            y = max(V + 15*((m+1)-i)-10); %using 'max' for robustness if specs change
            graph_points((i-1)*2*n + 2*(j-1)+1,:) = [x,y-1];
            graph_points((i-1)*2*n + 2*j,:) = [x,y-4];
            
        else
            
            x = mean(H + j*15);
            y = max(V + 15*((m+1)-i)-10); %using 'max' for robustness if specs change
            graph_points((i-1)*2*n + 2*(j-1)+1,:) = [x,y-1];
            graph_points((i-1)*2*n + 2*j,:) = [x,y-4];
            
        end
                
        %finds vertices along the columns
        if (mod(j,2)~=0)
            
            x1 = max(V + (j-1)*15-5);
            y1 = mean(H + 15*((m+1)-i)+5);
            graph_points(2*m*n + (i-1)*2*n + 2*(j-1)+1,:) = [x1+1,y1];
            graph_points(2*m*n + (i-1)*2*n + 2*j,:) = [x1+4,y1];
            
        else
            
            x1 = max(V + (j-1)*15-5);
            y1 = mean(H + 15*((m)-i)+5);
            graph_points(2*m*n + (i-1)*2*n + 2*(j-1)+1,:) = [x1+1,y1];
            graph_points(2*m*n + (i-1)*2*n + 2*j,:) = [x1+4,y1];
            
        end
    end   
end

if node_on == 1
    
   scatter( graph_points(:,1), graph_points(:,2), size );    
    
end

if text_on == 1
    
    for i = 1:(N/2)
        
        name=graph_points(i,:) + [-1,1.5];
        text(name(1),name(2),int2str(i));
        
    end
    
    for i = ((N/2)+1):N

        name = graph_points(i,:) - [2,-1];
        text(name(1),name(2),int2str(i));

    end
    
end

% hold off