function varargout = tlcc23(varargin)
% TLCC23 MATLAB code for tlcc23.fig
%      TLCC23, by itself, creates a new TLCC23 or raises the existing
%      singleton*.
%
%      H = TLCC23 returns the handle to a new TLCC23 or the handle to
%      the existing singleton*.
%
%      TLCC23('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TLCC23.M with the given input arguments.
%
%      TLCC23('Property','Value',...) creates a new TLCC23 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tlcc23_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tlcc23_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%------------------------------------------
% Copyright: Gerardo Lafferriere, 2019.  
% With assistance from Nathan Lawrence and Taiyo Terada.
% This project was funded by the National Institute for Transportation 
% and Communities (NITC; grant number 1165), a U.S. DOT University 
% Transportation Center.
%------------------------------------------

% Edit the above text to modify the response to help tlcc23

% Last Modified by GUIDE v2.5 06-Jan-2019 14:39:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tlcc23_OpeningFcn, ...
                   'gui_OutputFcn',  @tlcc23_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tlcc23 is made visible.
function tlcc23_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tlcc23 (see VARARGIN)

% Choose default command line output for tlcc23
pause('off')
handles.output = hObject;
disp('Running tlcc23.m')

%%Initializaton code for the urban traffic simulation
%We will start with a 2x3 grid, one-step graph, and 'light' traffic
%%Start initialization%%
axes(handles.SidePlot);
set(gca,'xtick',[])
set(gca,'ytick',[])
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% Remark: Street Grid size must be entered in this MATLAB file.  The
% interactive input is not available in this version.
handles.NumRows = 2;
handles.NumCols = 3;
% handles.NumRows = 3;
% handles.NumCols = 4;
NRows = handles.NumRows;
NCols = handles.NumCols;
NQueues = 4*NRows*NCols;
handles.NQueues = NQueues;
EditQueue = 1; %sliders will be set to display first queue information
handles.EditQueue = EditQueue;
set(handles.edit_queue,'string',num2str(EditQueue));
set(handles.Nrows,'string',num2str(NRows));
set(handles.Ncols,'string',num2str(NCols));
set(handles.graphselect,'Value',2);
set(handles.loadData,'UserData', 0)
% set(handles.select_scenario,'Value',2);

StreetDim = [NRows,NCols]; handles.StreetDim = StreetDim;
DirMat = QueuePlotDirection( StreetDim );
handles.DirMat = DirMat;

% For now, the SIMULATION Initial Queue lengths should be from 0 to 10
IQmax = 10;
handles.IQmax = IQmax;

%Initialize matrices
ComponentSwap = [1/3; 2/3];
handles.CompSwap = ComponentSwap;
Emat = exit_mat( StreetDim );

Af01 = one_step( StreetDim ); %flow matrix
%matches indices in Af01 to appropriate proportion
FlowIndMat = FindFlowMatInd( StreetDim, ComponentSwap );
%Flow matrix for the simulation
Af = [MakeStochastic( Af01, FlowIndMat ) zeros(NQueues, NRows+NCols);...
    Emat, zeros(NRows+NCols, NRows+NCols)];

%A crude way of choosing the defaults conflict matrix scheme
%0 for both lights being treated as pair.
PickConflict = 0;
handles.PickConflict = PickConflict;

if PickConflict == 1
    
    %This is the original conflict scheme
    Ac = [conflict( StreetDim ) zeros(NQueues, NRows+NCols);...
        zeros(NRows+NCols, NQueues + NRows+NCols)];
    %Random light arrangement
    ColorVec = RandLight( StreetDim, Ac );
    
else
    
    %This scheme treats each light pair as a unit
    Ac = [SimpleConflict( StreetDim ) zeros(NQueues, NRows+NCols);...
        zeros(NRows+NCols, NQueues + NRows+NCols)];
    %Random light arrangement
    ColorVec = SimpleRandLight( StreetDim );
    
    %%Important note: This does not make each light pair all green or all red, rather when
    %%a light is green, the pair in its immediate vicinity is all red. I
    %%believe making it so that each pair is always all green or all red
    %%would require tweaking the main loop a bit
    
end

A = Af01 + Af01';

handles.Ac = Ac;
handles.Af = Af;
handles.A = A;
handles.Emat = Emat;

hold on
%plotting the streetgrid and underlying graph of choice (one-step for now)
handles.NodePoints = streetgrid_plot( StreetDim, 1, 0 );
plot_graph( A, handles.NodePoints );
hold off

axes(handles.MainPlot);
set(gca,'xtick',[])
set(gca,'ytick',[])
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

hold on
NodePoints = streetgrid_plot( StreetDim, 0, 1 );
handles.NodePoints = NodePoints;
%saves initial queue lengths in handles as QVec
QVecMin = .5 + 2.5*rand(NQueues,1);
QVecMax = 3 + 6*rand(NQueues,1);
QnumHist = [];
QVec = QVecMin;
handles.QVecMin = QVecMin;
handles.QVecMax = QVecMax;
handles.QVec = QVec;
handles.QnumHist = QnumHist;
%QStart refers to reference points for plotting queues
[QStart, X, Y] = QData( NodePoints,QVec, DirMat );
handles.QStart = QStart;

for i = 1:NQueues
    
    fieldname = sprintf('Queue%d',i);
    handles.(fieldname) = fill( X(i,:)', Y(i,:)', 'b' );
    
end

set(handles.IQbox,'string',QVec(EditQueue));
set(handles.IQslider,'value',QVec(EditQueue)/IQmax);

%Initializing lights
[Lightx, Lighty] = light_calc( NodePoints, StreetDim );


% [handles.GreenFill, handles.RedFill] = light_plot( LightPoints, ColorVec );
% handles.LightPoints = LightPoints;
handles.Lightx = Lightx;
handles.Lighty = Lighty;
handles.ColorVec = ColorVec;

% The parameter for drawlights are:
%   QLights. This is an NQueues-dim vector.  It has a one if the
%   correcponding queue has a green light.  It should be checked that if two
%   queues share a light, the light can only be green for one of them.  This
%   should be encoded in the "conflict matrix" Ac.


for k=1:NQueues
    % Draw green and red lights based on the value of QLights.
    fieldname = sprintf('Light%d',k);
    x = Lightx(:,k);
    y = Lighty(:,k);
    if ColorVec(k)==1
        handles.(fieldname) = fill(x,y,'g');
    else
        handles.(fieldname) = fill(x,y,'r');
    end
    
end
drawnow
hold off

%Initialize the inflow rates

% r_in(i) is the number of vehicles that feed into road i during one 
% green cycle unit
% These will be prorated from an hourly rate.  
% Since one car goes through every 2 sec we divide by 1800.
IQFlowmax = 1200;
handles.IQFlowmax = IQFlowmax;
QInflowIndex = InitialInflowIndx( StreetDim );
handles.QInflowIndex = QInflowIndex;
% QInflowRates = zeros(NQueues + m + n,1);
IniFlowRatio = 3/12; %choose a method for finding an intial ratio for the inflow slider
handles.IniFlowRatio = IniFlowRatio;
%Multiplying by 1200 (max inflow rate), this gives the max inflow for each
%node -- allows the slider to set the inflow to zero -- see main loop
IFmaxDistrib = zeros(NQueues,1);
IFmaxDistrib( QInflowIndex ) = .8 + rand(length(QInflowIndex),1)*(1 - .8);
handles.IFmaxDistrib = IFmaxDistrib;
% QInflowMin = zeros(NQueues + m + n,1);
%IFidx acts as a log of all the queue indicies whose inflows have not been
%edited
IFidx = QInflowIndex;
IFidx = IFidx( IFidx ~= EditQueue );
QInflowRates = zeros(NQueues + NRows + NCols,1);
QInflowRates( IFidx ) = IFmaxDistrib( IFidx ).*IQFlowmax*IniFlowRatio;
QInflowRates( EditQueue ) = IQFlowmax*IniFlowRatio;
handles.IFidx = IFidx;
handles.QInflowRates = QInflowRates;

%Note this assumes the inflow comes from all peripheral streets -- will
%check the selection at the beginning of the run loop -- this index set
%QInflowIndex is a superset of all inflow index sets

% QInflowMin(IFidx) = randi([100,200],length(IFidx),1);
% QInflowMin( EQ ) = IQFlowmax*IniFlowRatio;
% 
% QInflowRates = QInflowMin;
% handles.QInflowRates = QInflowRates;
% handles.QInflowMin = QInflowMin;
% r_in = (1/1800)*QInflowRates;
% handles.r_in = r_in;
% Set up a max of 1200 for the scale of the sliders
set(handles.IRbox,'string',IQFlowmax*IniFlowRatio);
set(handles.IRslider,'value',IniFlowRatio);
set(handles.QSizeslide,'value', 0);
set(handles.QSizebox,'string',0);
set(handles.IFSizeslide,'value', IniFlowRatio);
set(handles.IFSizebox,'string',IniFlowRatio);

%For custom EW/NS inflow rates
NSFlowRatio=1/12;
EWFlowRatio=2/12;
set(handles.NSIFbox,'string',NSFlowRatio);
set(handles.NSIFslider,'value',NSFlowRatio);
set(handles.EWIFbox,'string',EWFlowRatio);
set(handles.EWIFslider,'value',EWFlowRatio);


if get(handles.EWNSIFCheckBox,'Value')
    EWIniFlowRatio=get(handles.EWIFslider,'value');
    NSIniFlowRatio=get(handles.NSIFslider,'value');
    
    IFidxEW = QInflowIndex(1:2*NRows);
    IFidxNS = QInflowIndex(2*NRows+1:end);
%     IFidx = IFidx( IFidx ~= EditQueue );%ignores EditQueue for
%     initialization
    IFmaxDistrib = ones(NQueues,1);
    %To add back random perturbation uncomment next line
%     IFmaxDistrib( QInflowIndex ) = .8 + rand(length(QInflowIndex),1)*(1 - .8);
    QInflowRates = zeros(NQueues + NRows + NCols,1);
    QInflowRates( IFidxEW ) = IFmaxDistrib( IFidxEW ).*IQFlowmax*EWIniFlowRatio;
    QInflowRates( IFidxNS ) = IFmaxDistrib( IFidxNS ).*IQFlowmax*NSIniFlowRatio;
%     QInflowRates( EditQueue ) = IQFlowmax*IniFlowRatio;
    handles.IFidxEW = IFidxEW;
    handles.IFidxNS = IFidxNS;
    handles.QInflowRates = QInflowRates;
end



% Intialize the car delays
MaxCarDelay = 3;
handles.MaxCarDelay = MaxCarDelay;
car_delay = ones(NQueues,1);
set(handles.CDbox,'string',car_delay(EditQueue));
set(handles.CDslider,'value',car_delay(EditQueue)/3);
handles.car_delay = car_delay;

% Intitalize the minimum Green light duration
MaxMinGreen = 4;
handles.MaxMinGreen = MaxMinGreen;
green_min = 3*ones(NQueues,1);
set(handles.MGbox,'string',green_min(EditQueue));
set(handles.MGslider,'value',green_min(EditQueue)/MaxMinGreen);
handles.green_min = green_min;

% Initialization for flash feature
FlashInd = [ 1 1 0 ];
ColorInd = 0;
handles.FlashInd = FlashInd;
handles.ColorInd = ColorInd;
%%End initialization%%

% Initializing propRatio value and box
propRatio=2/3;
set(handles.propslider,'value', propRatio);
set(handles.propbox,'string',propRatio);


pause('off')
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tlcc23 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tlcc23_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in RunButton.
function RunButton_Callback(hObject, eventdata, handles)
% hObject    handle to RunButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% L is the Laplacian for the communication between lights.
% Ac refers to a conflict graph indicating those roads governed by the same
% light. If two roads are "conflict" neighbors, then the light can only 
% be green for one of them at a time.
% Queues at thelights will grow due to a steady inflow.
% The states of the system are the lengths of the queues at all the lights.
% Our goal is to have them all be of equal length.  Hence the consensus approach.
%
% Example with nine roads and three intersections.  
% The last three roads are EXIT roads.  As such thay should ALWAYS have a 
% green light.  This will be indicated in the cgreen.m function.
% Moreover, this should keep the queue length at those road equal to zero and 
% hence, will be used to encourage queues 3, 4, 5, and 6 to try to 
% reduce their lengths.
% 
%      2|   4|   6| 
%   --1-+--3-+--5-+--- 9
%            |    |   
%            7    8
% Number of traffic light roads.  Each traffic light affects at least two roads.
uiresume;

NRows = handles.NumRows;
NCols = handles.NumCols;
NQueues = 4*NRows*NCols;
n = NQueues + NRows + NCols;
% Retrieve the Max Queue length to control congestion.
IQmax=handles.IQmax;
QVecMin = handles.QVecMin;
QVec = handles.QVec; %Queue lengths
% QInflowMin = handles.QInflowMin;
IQFlowmax = handles.IQFlowmax;
QInflowIndex = handles.QInflowIndex;
IFidx = handles.IFidx;
%intersecting all possible inflow indices with those that have not been
%edited yet
IFidx = intersect(QInflowIndex, IFidx);
QInflowRates = handles.QInflowRates;
QInflowRates( setdiff( [1:NQueues], QInflowIndex )) = 0;
IFmaxDistrib = handles.IFmaxDistrib;
EditQueue = handles.EditQueue;

car_delay = handles.car_delay;
green_min = handles.green_min;
% r_in = handles.r_in;
% r_in(1)

Ac = handles.Ac;
Af = handles.Af;
A = handles.A;
Emat = handles.Emat;

% Degree
A = [A, Emat'; Emat, zeros(NRows + NCols, NRows + NCols)];
D=sum(A');
% Laplacian.
L=diag(D)-A;

conf_idx = zeros(NQueues,4);
for kidx=1:NQueues
    idx_tmp=find(Ac(kidx,:));
    conf_idx(kidx,1:length(idx_tmp))=idx_tmp;
end

flow_idx = zeros(2,NQueues);
for kf=1:NQueues
    
    flow_idx(:,kf) = find(Af(:,kf));
    
end

% v is the "constant" speed at which vehicles feed the queues.
% v=1;
%
% T is the minimum time of a green cycle.
% We will assume that each unit of time equals 2 seconds.  This is the time 
% for a single car to go through a green light.  All the flow rates of cars will
% be in cars per hour.
T = 1;

x=zeros(n,1);
% The variable xinit will have the initial conditions.
xinit=zeros(n,1);
% Qfactor is a variable that adjusts the slider value from 0-1 to 0 to an
% appropriate number of cars.
Qfactor = 10;
xinit(1:NQueues) = QVec;
% for k=1:NQueues
%     % Read off the initial queue lengths from the Sliders.
%     sfieldname = sprintf('Q%dSlider',k);
%     qlength=get(handles.(sfieldname),'Value');
%     xinit(k)= Qfactor*qlength;
% end
%
% r_out(i) is the number of vehicle moving out of road i at each 
% green cycle unit.  

% Since we are now assuming a 2 sec green light unit, exactly one car will 
% go through each iteration.
%
% This r_out is for the consensus model since there is always one car per cycle.
% Consensus takes care of holding up cars upstream so that intermediate
% queues do not grow without bound.
r_out = ones(n,1);
rf_out = ones(n,1);

% r_in(i) is the number of vehicles that feed into road i during one 
% green cycle unit, where road(i) is on the periphery.
% For this example those roads are: 1, 2, 4.
%
% These will be prorated from an hourly rate.  
% Since one car goes through every 2 sec we divide by 1800.

%for NS/EW green light proportion set by propslider
propRatio=get(handles.propslider,'value');
comp1 = propRatio*ones(2*NRows*NCols,1);
comp2 = 1 - comp1;
prop = zeros(NQueues,1);
prop(1:2*NRows*NCols) = comp1; prop(2*NRows*NCols+1:end) = comp2;

  % In the next line the cycle_time represent the complete green-red cycle
  % duration for the proportional method.
cycle_time = 36;
light_ctr_lim = cycle_time*prop;
cycle_time_ctr=0;

%

%
%%%%%%%%%%%%%%%%%%%%%%%%%
% Main iteration is here.
%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 'niter' is the number of iterations of the simulation that we will run.
% niter=5400 corresponds to 3 hours since each iteration is 2 sec.
% niter=5400;
%
% Let's use 40 minutes.
niter=1200;
%
loadDataFlag=get(handles.loadData,'UserData');

y=zeros(n,niter);
yexit=zeros(NRows + NCols,niter);
y(:,1)=xinit;
% We will also store the green lights values for analysis.
% NOTE.  
%       green(i)=1 means the i-th queue has a green light.  
%       green(i)=0 means the i-th queue light is red.
%
green=zeros(NQueues,niter);
% Set an arbtrary intial green light vector.
green(:,1) = handles.ColorVec;
% green(:,1)=[1;0;0;1;0;1];
%%%%%%%%%%%%%%
% The following counters keep track of green lights.
%
light_ctr=zeros(NQueues,1);
% And set the initial green light vector for the fixed mode.
%REVISIT
fgreen  = [[green(:,1); zeros(NRows+NCols,1)] [zeros(NQueues+NRows+NCols,niter-1)]];
% fgreen=[1;0;0;1;0;1;0;0;0];
% 
yf(:,1)=xinit;
yfexit=zeros(3,niter);
StopFlag = 0;
pauseFlag=0;
SaveFlag=0;
set(handles.SaveButton,'UserData',0)
% scale is for plotting the queue boxes to scale in our current axes.
scale =1/5;
%
car_delay_ctr=zeros(NQueues,1);
% We need a separate counter for the carf_delay.
carf_delay_ctr=zeros(NQueues,1);
green_min_ctr=zeros(NQueues,1);

% car_delay = handles.car_delay;
%   car_delay = [str2num(get(handles.Car1Delay,'String'));
%       str2num(get(handles.Car2Delay,'String'));
%       str2num(get(handles.Car3Delay,'String'));
%       str2num(get(handles.Car4Delay,'String'));
%       str2num(get(handles.Car5Delay,'String'));
%       str2num(get(handles.Car6Delay,'String'))];
% Next we query for minimum greens.
% green_min = handles.green_min;
% For now we do no set minimum greens for the fixed pattern.
%
% The minimum green vector determines the minimum amount a light is turned
% green.  This could be different for each light.  At a minimum it is 3.
% Since car delays will be 1 a minimum of 3 will allow 2 cars to get
% through before it could turn red.

% For now use the same car delay for both the consensus and fixed approach.  For
% flexibility I will use a different variable.
carf_delay=car_delay;

FlashInd = handles.FlashInd;
ColorInd = handles.ColorInd;


%%%%%%
% NOW FOR THE MAIN LOOP.
%%%%%% 
if loadDataFlag
    file= handles.loadData1;
    load(file)
end

for k=1:niter-1

    %need this for the pause/step thru button to work
    if StopFlag > 0 || strcmp(pause('query'),'on')
        %% uncomment "keyboard" below for debugging breakpoint 
        %% that activates when you hit stop 
%         keyboard

        uiwait;
        % for saving data if SaveButton is pressed while stopped
        SaveFlag = get(handles.SaveButton,'Userdata');
        if SaveFlag>0
            StreetDim=handles.StreetDim;
            nrows=num2str(StreetDim(1));
            ncols=num2str(StreetDim(2));
            FileName=['tlccData_',nrows,'x',ncols,'_',datestr(now, 'mm-dd-yyyy_HH-MM'),'.mat'];
            save(FileName,'y','yf', 'green', 'fgreen', 'A', 'Ac', 'Af')
            disp(['Data Saved on file ',FileName]);
            SaveFlag=0;
            set(handles.SaveButton,'Userdata',0);
            uiwait;
        end

    end     
  % Display iteration number.
  IterText = num2str(k);
  set(handles.IterCounter,'String',IterText);
  % Display total cars in queues.
  CarCountText = num2str(round(sum(y(1:NQueues,k))));
  set(handles.CarCounter,'String',CarCountText);
  fCarCountText = num2str(round(sum(yf(1:NQueues,k))));
  set(handles.fCarCounter,'String',fCarCountText);
  if not(loadDataFlag)  
      % We adjust the number of cars that get added/subtracted each iteration
      % with two components:
      % cars_out: the number of cars leaving this road/queue with a green light.
      % We also determine who gets the green light comparing the queue lengths
      % among conflicting queues (that is, queues that share a light).
      % For now, only two queues share each light.  This determination is done
      % in the function "cgreen(x)".
      % 
      % We implement a 0-1 consensus law where we will adjust the queue lengths
      % by one or zero units each time based on whether the corresponding
      % consensus value is positive or negative.
      y_cons = ((L*y(:,k))>0);
      % We now compute an auxiliary variable tmp_green that will help us
      % determine the correct green value for the next iteration. 
      % This is a product of the consensus value and the cgreen(x) value. 
      % The first factor determines if the light turns green for 
      % the corresponding road (among conflicting ones). 
      % The second (Lapacian) factor computes the "average"
      % differences to compare to other roads.
      % We only use the Laplacian values when they are positive, since we cannot
      % add cars to a queue.  We can only keep the light red.
      tmp_green = cgreen(y(:,k), Ac).*y_cons;
      % We use the old  cars_out formula to fill in the exit queues. cars_out
      % will be overwritten for entries 1 through NQueues.
      cars_out = min(cgreen(y(:,k), Ac).*r_out.*((L*y(:,k))>0), y(:,k));
      % Next, we determine the true green value and the actual cars_out value.

      %  We must account for three issues:
      % minimum green times, car delays at start up, and congestion at the
      % outflow queue. 
      %
      

    for kg=1:NQueues

        %using idx instead of conf_idx
        %idx = find(Ac(kg,:)); 
        % Recover only the nonzero entries of the conflict list of indices.
        idx = conf_idx(kg,conf_idx(kg,:)>0);

        %for l = 1:length(idx)
            switch tmp_green(kg)
                case 0
                    % This case is asking that we turn (or keep) the light red.
                    switch green(kg,k)
                        case 0
                            % In this case we do nothing since light was red
                            % already, so it stays red.
                            %  No cars go out.  No counters need updating.
                            green(kg,k+1)= 0;
                            cars_out(kg)=0;
                        case 1
                            % Here the light was green and we must determine if
                            % the light indeed can turn
                            % red, based on a minimum green time.
                            if green_min_ctr(kg)<green_min(kg)
                                % Not enough time has passed to turn light red.
                                % We must keep light green.
                                green(kg,k+1)=1;
                                % Update green_min counter
                                green_min_ctr(kg)=green_min_ctr(kg) + 1;
                                % We also must make sure the conflicting lights
                                % stay red.  Here we loop over all conflicting
                                % lights.
                                for kc=1:length(idx)
                                    green(idx(kc),k+1) = 0;
                                % And we change tmp_green in case the
                                % conflicting indeces come later.
                                    tmp_green(idx(kc)) = 0;
                                % NOTE: the is no risk of violating the min_green
                                % time for the conflicting lights since at the kth
                                % iteration they should have been red (value=0) in our
                                % current case.
                                %                            
                                end
                                % Now we determine whether cars go out.  We check
                                % the delay counter.
                                if  car_delay_ctr(kg)<car_delay(kg)
                                    cars_out(kg)=0;
                                else
                                    % Only one car may pass through each
                                    % iteration.  Unless there is less than 1 car in the
                                    % queue.
                                    cars_out(kg) = min(1,floor(y(kg,k)));
                                end
                                % Update the car_delay counter.
                                car_delay_ctr(kg)=car_delay_ctr(kg)+1;
                            else
                                % Light may turn red.
                                green(kg,k+1) = 0;
                                % The next "if" is added to allow zero delays for
                                % cars. Unless car_delay is zero there should be
                                % no cars coming out right now.

                                %cars_out not all %1s and 0s in else statement
                                if car_delay_ctr(kg)<car_delay(kg)
                                    % No cars go out due to delay.
                                    cars_out(kg)=0;
                                else
                                    % Cars can go out now unless there is
                                    % less than 1 car in the queue.
                                    cars_out(kg)=min(1,floor(y(kg,k)));
                                end
                                % Reset the counters.
                                green_min_ctr(kg) = 0;
                                car_delay_ctr(kg)=0;
                            end
                        otherwise
                            disp('Error: green should be either 0 or 1')
                            green_value=green(kg,k);
                    end % End of second (inner) switch.

                case 1
                    switch green(kg,k)
                        case 0
                           % Here we must check whether we can indeed turn from
                            % red to green based on the conflicting lights minimum
                            % green time, if one was green the previous iteration.
                            %
                            % We chck if all of the conflicting lights are
                            % red.
                            conf_red=sum(green(idx(:),k));
                            if conf_red == 0
                                % All conflict lights were red the previous
                                % iteration.  There is no problem: we turn this
                                % light green.
                                green(kg,k+1)=1;
                                % Unless car_delay is zero there should be no cars
                                % coming out.

                                if car_delay_ctr(kg)<car_delay(kg)
                                    % No cars go out due to delay.
                                    cars_out(kg)=0;
                                else
                                    % Cars can go out now unless there is
                                    % less than 1 car in the queue.
                                    cars_out(kg)=min(1,round(y(kg,k)));
                                end
                                % We update the counters.
                                car_delay_ctr(kg)=car_delay_ctr(kg)+1;
                                green_min_ctr(kg)=green_min_ctr(kg)+1;
                            else
                                % At least one conflict light was green at the previous
                                % iteration so we should check for minimum green
                                % time.
                                %

                               conf_green = sum(green_min_ctr(idx(:))<green_min(idx(:)));

                                if conf_green > 0
                                    % In this case we cannot change because
                                    % at least on of the conficting lights has
                                    % not been green long enough.
                                    green(kg,k+1)=0;
                                    % No cars can go out.
                                    cars_out(kg)=0;
                                    % We do not update any counters.  They should
                                    % stay at zero from when the light turned red.
                                else
                                    % In this case, it is OK to change.
                                    green(kg,k+1)=1;
                                    % Since this light is set to 1 the other ones would
                                    % have been set to 0 in tmp_green and would
                                    % go through the proper switch to be turned
                                    % red.  The only case in which a light would
                                    % be kept green against the value in
                                    % tmp_green is if the minimum green time had
                                    % not been met, which is not the case here.
                                    % Unless car_delay is zero there should be no
                                    % cars coming out.
                                    if car_delay_ctr(kg)<car_delay(kg)
                                        % No cars go out due to delay.
                                        cars_out(kg)=0;
                                    else
                                        % Cars can go out now unless there is
                                        % less than 1 car in the queue.
                                        %REVISIT - no outputs
                                        cars_out(kg)=min(1,round(y(kg,k)));
                                    end
                                    % Either way we update the counters.
                                    car_delay_ctr(kg)=car_delay_ctr(kg)+1;
                                    green_min_ctr(kg)=green_min_ctr(kg)+1;
                                end
                            end
                        case 1
                            % In this case the conflicting lights would be
                            % 0, so there is no conflict to keep the green on.
                            green(kg,k+1)=1;
                            % Check that cars can go out.
                            if car_delay_ctr(kg)<car_delay(kg)
                                % No cars can go out yet.
                                %REVISIT - virtually all 0s, only one update
                                cars_out(kg)=0;
                            else
                                % Cars can go out now unless there is less than 1
                                % car in the queue.

                                
                                cars_out(kg)=min(1,floor(y(kg,k)));
                            end
                            % Either way we update the counters.
                            car_delay_ctr(kg)=car_delay_ctr(kg)+1;
                            green_min_ctr(kg)=green_min_ctr(kg)+1;
                        otherwise
                            disp('Error: green should be either 0 or 1')
                            green_value=green(kg,k);
                    end
                otherwise
                    disp('Error: Green should be 0 or 1')
                    green_value=green(kg,k+1);
            end
        %end
    end
    
    %here we loop through the preexit queues to turn them green
    %if all conflicting queues are red
%     
%     preExit=find(Af'*[zeros(NQueues,1);ones(length(yexit(:,1)),1)]);
%     %for 2x3 should return this 
%     %kcongest=[3 5 7 8 12 15 18 19 20 24]';
% 
%     for kc = randperm(length(preExit))
%         kcong=preExit(kc)
%         %using idx instead of conf_idx
%         % Recover only the nonzero entries of the conflict list of indices.
%         idx = conf_idx(kcong,conf_idx(kcong,:)>0);
%         if not(green(kcong,k+1))
%                 % In this case we check if all conflicting lights
%                 % are red in which case we turn it green
%           if all(not(green(idx,k+1)))
%                 green(kcong,k+1)= 1;
%                 cars_out(kcong)=min(1,floor(y(kcong,k)));
%           end
%         end
%     end
      % Now we account for congestion downstream.  We check to see if those
      % queues with green lights can actually let cars go through based on the
      % queues downstream.
      for kf = 1:NQueues
          % If the down flow queue is full we set cars_out to 0.
          %REVIST - check the if statement

          idx = find( Af( :, kf ) );

          for l = 1:length(idx)

              if y(idx(l),k) >= IQmax%- 2
    %           if sum(y(idx,k) >= IQmax - 2) >= length(idx)

                  cars_out(kf) = 0;

              end

          end

      end

    %       if (y(flow_idx(1,kf),k) >= IQmax-5) || (y(flow_idx(2,kf),k) >= IQmax-5)
    %           cars_out(kf)=0;


      % cars_in: this has two terms.  The first determines the cars that will
      % come in from a feeder road provided they get the green light and the 
      % Laplacian says the queue should decrease.  In other words, this should
      % be the value of cars_out from all the feeder roads combined. 
      % The second term is a term 
      % that only affects the peripheral roads
      % and determines the total number of cars entering the system.
      % 
      % 
      % First we query the inflow sliders to update the rates.
    %   rin_hourly = [ 1200*(QVec/10); zeros(NRows + NCols,1) ];
    %   QInflowRates( QInflowIndex ) = min( abs( IQFlowmax - QInflowMin( QInflowIndex ) )*ratio + QInflowMin( QInflowIndex ), IQFlowmax );

    % rin_hourly = handles.QInflowRates;


    %IMPORTANT: It seems matlab will only use the handles information from
    %before 'run' was clicked unless that information comes from the 'get' or
    %'set' functions -- therefore, the following assingnments use the ratios
    %from the sliders, then use that information INSIDE this loop to generate
    %new inflow data on the fly. No need to perform the following calculations
    %inside the slider/box callbacks.

    ratio=get(handles.IFSizeslide,'Value');
    %Note that this counts an index that has been entered in "edit queue"
    %even without changing anything
    EQ = str2num(get(handles.edit_queue, 'string'));
    IFidx = IFidx( IFidx ~= EQ );
    if get(handles.EWNSIFCheckBox,'Value')
        EWIniFlowRatio=get(handles.EWIFslider,'value');
        NSIniFlowRatio=get(handles.NSIFslider,'value');
        IFidxEW = QInflowIndex(1:2*NRows);
        IFidxNS = QInflowIndex(2*NRows+1:end);
%         %ignores EditQueue for now
%         IFidxEW = IFidxEW( IFidxEW ~= EQ )
%         IFidxNS = IFidxNS( IFidxNS ~= EQ )
        IFmaxDistrib = ones(NQueues,1);%previously had random perturbation
        %previously had random perturbation to add back uncomment line below
%         IFmaxDistrib( QInflowIndex ) = .8 + rand(length(QInflowIndex),1)*(1 - .8);
        QInflowRates = zeros(NQueues + NRows + NCols,1);
        QInflowRates( IFidxEW ) = IFmaxDistrib( IFidxEW ).*IQFlowmax*EWIniFlowRatio;
        QInflowRates( IFidxNS ) = IFmaxDistrib( IFidxNS ).*IQFlowmax*NSIniFlowRatio;
%         %ignores EditQueue for now
%         QInflowRates( EQ ) = IQFlowmax*get(handles.IRslider,'value');
        handles.IFidxEW = IFidxEW;
        handles.IFidxNS = IFidxNS;
        handles.QInflowRates = QInflowRates;
    else
        QInflowRates( IFidx ) = IFmaxDistrib( IFidx ).*IQFlowmax*ratio;
        %Here is an extra layer of flexibility: although all the sliders cannot be
        %pushed to IQFlowmax simultaneously, they may individually
        QInflowRates( EQ ) = IQFlowmax*get(handles.IRslider,'value');
    end
    % X0 = -QInflowMin( IFidx )./( IQFlowmax - QInflowMin( IFidx ) );
    % X0 = -QInflowMin./( IQFlowmax - QInflowMin );

    % QInflowRates( IFidx ) = min(( IQFlowmax - QInflowMin( IFidx )).*...
    %     ((1-X0(IFidx))*ratio + X0(IFidx) ) + QInflowMin( IFidx ), IQFlowmax );
    % 
    % x0 = -QInflowMin( EQ )./( IQFlowmax - QInflowMin( EQ ) );
    % 
    % QInflowRates( EQ ) = min( abs( IQFlowmax - QInflowMin( EQ ) ).*...
    %     ((1-x0)*get(handles.IRslider,'value') + x0) + QInflowMin( EQ ), IQFlowmax );

    handles.QInflowRates = QInflowRates;

    % set(handles.IRslider,'value',QInflowRates( EQ )/IQFlowmax);
    % set(handles.IRbox,'string',num2str(QInflowRates( EQ )));

    rin_hourly = QInflowRates;

      r_in=1/1800*rin_hourly;

      % We offer two alternatives for the arrivals: fixed rate or Poisson.
      % ArrivalMode: 0 for fixed rate, 1 for Poisson.
      % Read current choice from the GUI button.
      % We only update the rate once per cycle_time.
%       ArrivalMode = 0;
      if cycle_time_ctr==0
          ArrivalMode = get(handles.IFNoiseCheckBox,'Value');
          if ArrivalMode == 0
              % Arrivals come at the rate in rin_hourly.  It takes 2 seconds er car
              % to pass.
              r_in = 1/1800*rin_hourly;
    %           r_in = handles.r_in;
    %           r_in(1)
          else
              %Arrivals come as a Poisson process.
              r_in = 1/1800*poissrnd(rin_hourly);
          end
      end
      cycle_time_ctr=mod(cycle_time_ctr+1,cycle_time);
      cars_in = Af*(cars_out.*rf_out) + r_in;
      cars_delta=cars_in-cars_out;

      cars_delta(NQueues+1:end) = 0;
      y(:,k+1) = max(y(:,k) + cars_delta,0);

      Emat = handles.Emat;
      for i = 1:(NRows + NCols)

          ind = find( Emat(i,:) );
          yexit(i,k+1) = min( cars_out(ind(1)) + cars_out(ind(2)),...
              y(ind(1),k) + y(ind(2),k) );

      end
      
    %   update prop vector for all ew/ns
    propRatio=get(handles.propslider,'value');
    comp1 = propRatio*ones(2*NRows*NCols,1);
    comp2 = 1 - comp1;
    prop = zeros(NQueues,1);
    prop(1:2*NRows*NCols) = comp1; prop(2*NRows*NCols+1:end) = comp2;
    light_ctr_lim = cycle_time*prop;
       % First determine which green lights should change for this cycle.
    
    fgreen(:,k+1)=fgreen(:,k);
    for k1=1:NQueues
        if fgreen(k1,k+1)==1
            if light_ctr(k1)<light_ctr_lim(k1)
                light_ctr(k1)=light_ctr(k1)+1;
            else
                fgreen(k1,k+1)=0;
                %using this instead of conf_idx
                fgreen(Ac(k1,:)==1,k+1) = 1;
                %       light_ctr
                light_ctr(k1)=0;
            end
            
        end

    end
    %
    % First we compute the cars_out in the old way.  However, we will need to
    % determine the actual cars_out based on car_delay.
      cars_out = min(fgreen(:,k+1).*rf_out,yf(:,k));
      % Now determine if cars actually go out based on the car_delay parameter.
      % Use the same as car_delay, for now.
      carf_delay=car_delay;
      for kg=1:NQueues
          % We only check for car delays if the light is green.  Otherwise
          % cars_out was already set to zero.
          switch fgreen(kg,k+1)
              case 0
                  % The light is red so no cars go out.  Reset the car_delay
                  % counter to zero.
                  cars_out(kg)=0;
                  carf_delay_ctr(kg)=0;
              case 1
                  % The light is green.  We check for car delays.
                  if carf_delay_ctr(kg)<carf_delay(kg)
                      % No cars go out due to delay.
                      cars_out(kg)=0;
                  else
                      % Cars go out unless there is less than 1 car in the queue.
                      cars_out(kg)=min(1,round(yf(kg,k)));
                  end
                  % We update the counters.
                  carf_delay_ctr(kg)=carf_delay_ctr(kg)+1;
          end
      end
      % Now we account for congestion downstream.  We check to see if those
      % queues with green lights can actually let cars go through based on the
      % queues downstream.
      for kf = 1:NQueues
          % If the down flow queue is full we set cars_out to 0.
          %REVIST - check the if statement

          idx = find( Af(:, kf ) );

          for l = 1:length(idx)

    %           if sum(y(idx,k) >= IQmax - 2) >= length(idx)
              if yf(idx(l),k) >= IQmax%2
                  cars_out(kf)=0;
              end 

          end   
      end

      cars_in = Af*(cars_out.*rf_out) + r_in;
      cars_delta=cars_in-cars_out;

      cars_delta(NQueues+1:end) = 0;

      yf(:,k+1)=max(yf(:,k) + cars_delta,0);

      Emat = handles.Emat;
      for i = 1:(NRows + NCols)

          ind = find( Emat(i,:) );
          yfexit(i,k+1) = min( cars_out(ind(1)) + cars_out(ind(2)),...
              yf(ind(1),k) + yf(ind(2),k) );

      end
%   
  end %for conditional for loaded data case

  % Finally we decide which of the two evolutions to display based on the
  % simulation flag: 0 for Consensus, 1 for Proportional.
  SimuFlag = get(handles.SimuToggle,'Value');
  
%   SimuFlag = 0;
  if SimuFlag == 0
      handles.QVec= y(1:NQueues,k+1);
      handles.ColorVec = green(1:NQueues,k+1);
      guidata(hObject, handles);
  else
      handles.QVec= yf(1:NQueues,k+1);
      handles.ColorVec = fgreen(1:NQueues,k+1);
      guidata(hObject, handles);
  end
  
  if mod(k,10) == 0
      
      if mod(ColorInd, 2) == 0
          
          handles.FlashInd = [1 1 0];
          
      else
          
          handles.FlashInd = [0.9100    0.4100    0.1700];
          
      end
      ColorInd = ColorInd + 1;
  end
  
  % Update Lights and Queues.  
  UpdateLights(handles);
  UpdateQueues(handles);
  
  StopFlag = get(handles.StopButton,'Userdata');

%   handles.QVec = QVec;
  guidata(hObject, handles);
    
end

uiwait;%waiting incase you want to save full simulation data

SimuFlag = get(handles.SimuToggle,'Value');
%REVISIT -- SimuToggle not working correctly
%   SimuFlag = 0;
if SimuFlag == 0
  handles.QVec= y(1:NQueues,k+1);
  handles.ColorVec = green(1:NQueues,k+1);
  guidata(hObject, handles);
else
  handles.QVec= yf(1:NQueues,k+1);
  handles.ColorVec = fgreen(1:NQueues,k+1);
  guidata(hObject, handles);
end
UpdateLights(handles);
UpdateQueues(handles);
SaveFlag = get(handles.SaveButton,'Userdata');
if SaveFlag>0
    StreetDim=handles.StreetDim;
    nrows=num2str(StreetDim(1));
    ncols=num2str(StreetDim(2));
    FileName=['tlccData_',nrows,'x',ncols,'_',datestr(now, 'mm-dd-yyyy_HH-MM'),'.mat'];
    save(FileName,'y','yf', 'green', 'fgreen', 'A', 'Ac', 'Af')
    disp(['Data Saved on file ',FileName]);
    SaveFlag=0;
    set(handles.SaveButton,'Userdata',0);
%     FileName=['tlccDataFull',datestr(now, 'mm-dd-yyyy_HH-MM'),'.mat'];
%     save(FileName,'y','yf', 'green', 'fgreen', 'A', 'Ac', 'Af')
%     SaveFlag=0;
%     set(handles.SaveButton,'Userdata',0);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
% END of RUN LOOP
%%%%%%%%%%%%%%%%%%%%%%%%%%

% cgreen(x)
%
% computes an indicator vector (of ones and zeros) that indicate the entry
% with the maximum value of traffic queues among conflicting roads: those
% are roads that meet at a street light.  Essentially, this decides who 
% gets the green light.
function ym=cgreen(x, Ac)
%   Ac = handles.Ac;
  [NQueues,~] = size(Ac);
  ym=zeros(size(x));
  Atemp = Ac*diag(x);
  [xmax,xmax_id]=max(Atemp');
  for k=1:length(x)
    if ((x(k)>xmax(k)) || ((x(k)==xmax(k)) && (k<xmax_id(k))))
    ym(k)= 1;
    end
  end
  ym(NQueues+1:end) = 1;

%End of cgreen.

function UpdateQueues(handles)
% Update the queue boxes.  This is used both by the Initial Queues Sliders
% and by the main code as the simulation runs.

NQueues=handles.NQueues;
NRows = handles.NumRows;
NCols = handles.NumCols;
DirMat = handles.DirMat;
QStart = handles.QStart;
QVec = handles.QVec;
IQmax = handles.IQmax;
QInflowIndex = handles.QInflowIndex;
FlashInd = handles.FlashInd;
N = 4*NRows*NCols; M = N/2;

QVec( QVec > IQmax ) = IQmax;

QStart1 = QStart(1:M,:);
QStart2 = QStart((M+1):end,:);

DirMat1 = DirMat(:,1); DirMat2 = -1*DirMat(:,2);

UpdateXData = QStart1(:,1) + DirMat1.*QVec(1:M);
UpdateYData = QStart2(:,3) + DirMat2.*QVec((M+1):end);

X = cat(2,QStart(:,1),cat(1,UpdateXData,QStart2(:,2)),cat(1,UpdateXData,...
    QStart2(:,2)),QStart(:,1));

Y = cat(2, cat(1,QStart1(:,2),QStart2(:,3)), cat(1,QStart1(:,2),QStart2(:,3)),...
    cat(1,QStart1(:,3),UpdateYData), cat(1,QStart1(:,3),UpdateYData) );

%Change color of queue if it exceeds IQmax+1 ( because they are floats)
QMaxInd = find( QVec >= IQmax );
MinusQMaxInd = setdiff( [1:NQueues], QMaxInd );

QVecOuter = QInflowIndex( find( QVec( QInflowIndex ) >= IQmax ));
QVecInner = setdiff( QMaxInd, QInflowIndex );
l1 = length(QVecOuter);
l2 = length(QVecInner);
l3 = length(MinusQMaxInd);

for i = 1:l1
    
    qfieldname = sprintf('Queue%d',QVecOuter(i));
    handles.(qfieldname).FaceColor = [1 1 0];
    
end

%makes inner ques flash orange
for i = 1:l2
    
    qfieldname = sprintf('Queue%d',QVecInner(i));
    handles.(qfieldname).FaceColor = FlashInd;
    
end

%Accounts for queues that emptied below IQmax
for i = 1:l3
   
    qfieldname = sprintf('Queue%d',MinusQMaxInd(i));
    handles.(qfieldname).FaceColor = [0 0 1];    
    
end

for k = 1:NQueues
    
%     if QVec( k ) >= IQmax
%         
%         qfieldname = sprintf('Queue%d',k);
%         handles.(qfieldname).FaceColor = [1 1 0];
%         
%     end
    
    qfieldname = sprintf('Queue%d',k);
    handles.(qfieldname).XData = X(k,:)';
    handles.(qfieldname).YData = Y(k,:);
    
end
drawnow

%End of UpdateQueues

function UpdateLights(handles)
% Draw green triangle to show which direction the light is green at each
% iteration.
%NLights=3;
NQueues = handles.NQueues;
% We think of linghts as corresponding to each queue.  A value of 1 for the
% corresponding light means that queue gets the green light and the
% conflicting queue gets a red light.
% LGreenx and LGreeny have as many columns as there are queues.
% LGreenx = [17.5, 17.5, 32.5, 32.5, 47.5, 47.5;
%     15, 19, 30, 34, 45, 49;
%     15, 16, 30, 31, 45, 46];
% LGreeny = [22.5, 22.5, 22.5, 22.5, 22.5, 22.5;
%     24, 25, 24, 25, 24, 25;
%     21, 25, 21, 25, 21, 25];
% LightPoints = handles.LightPoints;
% Lightx = handles.Lightx;
% Lighty = handles.Lighty;
% The light direction depends on which queue should get the green light
% and it is encoded in ColorVec.
ColorVec = handles.ColorVec;

for k=1:NQueues
    % Build fieldnames to make the looping easier.
    Lfieldname = sprintf('Light%d',k);
    if ColorVec(k)==1
        handles.(Lfieldname).FaceColor = 'g';
    else
        handles.(Lfieldname).FaceColor = 'r';
    end
end
drawnow

%End of UpdateLights

function handles = PlotQueues(handles)
%NodePoints indicates where the nodes are located. This will determine
%where the queue boxes begin. QVec will determine where the
%queue boxes end (how 'long' the box is)

gp = handles.NodePoints;
QVec = handles.QVec;
DirMat = handles.DirMat;
[N,~] = size(gp); M = N/2;

DirMat1 = DirMat(:,1); DirMat2 = DirMat(:,2);

X11 = gp(1:M,1) + (-5)*DirMat1; X12 = X11 + QVec(1:M).*DirMat1;
X21 = gp((M+1):end,1) - .5; X22 = gp((M+1):end,1) + .5;
X1 = cat(1, X11, X21); X2 = cat(1, X12, X22);

Y11 = gp(1:M,2) - .5; Y12 = gp(1:M,2) + .5;
Y21 = gp((M+1):end,2) + 5*DirMat2; Y22 = Y21 + (-1)*QVec((M+1):end).*DirMat2;
Y1 = cat(1, Y11, Y21); Y2 = cat(1, Y12, Y22);

X = cat(2, X1, X2, X2, X1);
Y = cat(2, Y1, Y1, Y2, Y2);

QStart1 = cat(2, X11, Y11, Y12);
QStart2 = cat(2, X21, X22, Y21);
QStart = cat(1, QStart1, QStart2);
handles.QStart = QStart;

for k = 1:N
    
    fieldname = sprintf('Queue%d',k);
    handles.(fieldname) = fill( X(k,:)', Y(k,:)', 'b' );
    
end
drawnow


%End of PlotQueues

% --- Executes on button press in PauseButton.
function PauseButton_Callback(hObject, eventdata, handles)
% hObject    handle to PauseButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of PauseButton

button_state = get(hObject,'Value');
if button_state == get(hObject,'Min')
    pause('off')
    set(handles.PauseButton,'string','Step Off','BackgroundColor',[0.9,0.7,0]);
elseif button_state == get(hObject,'Max')
	pause('on')
    set(handles.PauseButton,'string','Step On','BackgroundColor',[0,0.8,1]);
end

% --- Executes on button press in StopButton.
function StopButton_Callback(hObject, eventdata, handles)
% hObject    handle to StopButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
stoptest=get(handles.StopButton,'UserData');
if stoptest ==0
    set(handles.StopButton,'UserData', 1)
    set(handles.StopButton,'string','Start','BackgroundColor',[0.9,0.7,0]);
else   
    set(handles.StopButton,'UserData', 0)
    set(handles.StopButton,'string','Stop','BackgroundColor',[0,0.8,1]);
    uiresume;
end
guidata(hObject,handles);



% --- Executes on button press in ResetButton.
function ResetButton_Callback(hObject, eventdata, handles)
% hObject    handle to ResetButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Reset preserves the current street dimensions but reinitializes everything
%the same way as seen in the initialization scheme.
%I removed just about everything from the street dimension box callbacks.
%After changing the street dimensions simply click 'reset'

set(handles.StopButton,'Userdata',0);
set(handles.loadData, 'Value', 0)
uiresume;
EditQueue = 1;
handles.EditQueue = EditQueue;
NRows = handles.NumRows;
NCols = handles.NumCols;
StreetDim = [NRows, NCols];
NQueues = 4*NRows*NCols;
handles.NQueues = NQueues;
IQmax = handles.IQmax;
PickConflict = handles.PickConflict;

DirMat = QueuePlotDirection( StreetDim );
handles.DirMat = DirMat;
Emat = exit_mat( StreetDim );
FlowIndMat = FindFlowMatInd( StreetDim, handles.CompSwap );
Af01 = one_step( StreetDim );
Af = [MakeStochastic( Af01, FlowIndMat ) zeros(NQueues,NRows+NCols);...
    Emat, zeros(NRows+NCols,NRows+NCols)];

A = Af01 + Af01';

if PickConflict == 1
    
    %This is the original conflict scheme
    Ac = [conflict( StreetDim ) zeros(NQueues, NRows+NCols);...
        zeros(NRows+NCols, NQueues + NRows+NCols)];
    %Random light arrangement
    ColorVec = RandLight( StreetDim, Ac );
    
else
    
    %This scheme treats each light pair as a unit
    Ac = [SimpleConflict( StreetDim ) zros(NQueues, NRows+NCols);...
        zeros(NRows+NCols, NQueues + NRows+NCols)];
    %Random light arrangement
    ColorVec = SimpleRandLight( StreetDim );

end

QnumHist = [];
QVecMin = .5 + 2.5*rand(NQueues,1); 
QVecMax = 3 + 6*rand(NQueues,1);
QVec = QVecMin;
handles.QnumHist = QnumHist;
handles.QVecMin = QVecMin;
handles.QVecMax = QVecMax;
handles.QVec = QVec;
NodePoints = NodePointsData( StreetDim );
[QStart, X, Y] = QData( NodePoints, QVec, DirMat );
handles.QStart = QStart;
[Lightx, Lighty] = light_calc( NodePoints, StreetDim );

% QInflowIndex = InitialInflowIndx( StreetDim );
% QInflowRates = zeros(NQueues + NRows + NCols,1); %REVISIT
% QInflowRates( QInflowIndex ) = randi([100,200],length(QInflowIndex),1);
% QInflowMin = QInflowRates;

% r_in = (1/1800)*QInflowRates;
% car_delay = ones(NQueues,1);
% green_min = 3*ones(NQueues,1);

FlashInd = [ 1 1 0 ];
ColorInd = 0;
pause('off')

axes(handles.SidePlot);
cla;
set(gca,'xtick',[])
set(gca,'ytick',[])
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

set(handles.edit_queue,'string',num2str(EditQueue));
set(handles.Nrows,'string',num2str(NRows));
set(handles.Ncols,'string',num2str(NCols));
set(handles.graphselect,'Value',2);
set(handles.IFselect,'Value',1);

% set(handles.select_scenario,'Value',2);
hold on
handles.NodePoints = streetgrid_plot( StreetDim, 1, 0 );
plot_graph(A, NodePoints )
hold off

axes(handles.MainPlot);
cla;
set(gca,'xtick',[])
set(gca,'ytick',[])
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

hold on

%Reinitialize inflow rates
QInflowIndex = InitialInflowIndx( StreetDim );
IniFlowRatio = handles.IniFlowRatio; %choose a method for finding an intial ratio for the inflow slider
IQFlowmax = handles.IQFlowmax;
IFidx = QInflowIndex( QInflowIndex~= EditQueue );

IFmaxDistrib = zeros(NQueues,1);
IFmaxDistrib( QInflowIndex ) = .8 + rand(length(QInflowIndex),1)*(1 - .8);
handles.IFmaxDistrib = IFmaxDistrib;
QInflowRates = zeros(NQueues + NRows + NCols,1);
QInflowRates( IFidx ) = IFmaxDistrib( IFidx ).*IQFlowmax*IniFlowRatio;
QInflowRates( EditQueue ) = IQFlowmax*IniFlowRatio;
handles.IFidx = IFidx;
handles.QInflowRates = QInflowRates;
handles.QInflowIndex = QInflowIndex;


% UpdateQueues(handles)
NodePoints = streetgrid_plot( StreetDim, 0, 1 );
hold on

%Yes, there are functions for updating/plotting the queues, but they are
%not good for initialization purposes -- I could not get the handles
%structure to update inside those functionsmm -- guidata(hObject,handles);
%does not work in them because 'hObject' does not exist
for i = 1:NQueues
    
    fieldname = sprintf('Queue%d',i);
    handles.(fieldname) = fill( X(i,:)', Y(i,:)', 'b' );
    
end


set(handles.IRbox,'string',IQFlowmax*IniFlowRatio);
set(handles.IRslider,'value',IniFlowRatio);
set(handles.IFSizeslide,'value', IniFlowRatio);
set(handles.IFSizebox,'string',IniFlowRatio);

set(handles.IQbox,'string',QVec(EditQueue));
set(handles.IQslider,'value',QVec(EditQueue)/IQmax);
set(handles.QSizeslide,'value', 0);
set(handles.QSizebox,'string',0);
set(handles.IFSizeslide,'value', IniFlowRatio);
set(handles.IFSizebox,'string',IniFlowRatio);

%Reinitialize car delays
MaxCarDelay = handles.MaxCarDelay;
car_delay = ones(NQueues,1);
set(handles.CDbox,'string',car_delay(EditQueue));
set(handles.CDslider,'value',car_delay(EditQueue)/3);

% Reintitalize the minimum Green light duration
MaxMinGreen = handles.MaxMinGreen;
green_min = 3*ones(NQueues,1);
set(handles.MGbox,'string',green_min(EditQueue));
set(handles.MGslider,'value',green_min(EditQueue)/MaxMinGreen);

for k=1:NQueues
    % Draw green and red lights based on the value of QLights.
    fieldname = sprintf('Light%d',k);
    x = Lightx(:,k);
    y = Lighty(:,k);
    if ColorVec(k)==1
        handles.(fieldname) = fill(x,y,'g');
    else
        handles.(fieldname) = fill(x,y,'r');
    end
    
end
drawnow
hold off

handles.StreetDim = StreetDim;
handles.Af = Af;
handles.Ac = Ac;
handles.A = A;
handles.Emat = Emat;
handles.NodePoints = NodePoints;
handles.Lightx = Lightx;
handles.Lighty = Lighty;
handles.ColorVec = ColorVec;
handles.QInflowIndex = QInflowIndex;
handles.QInflowRates = QInflowRates;
% handles.QInflowMin = QInflowMin;
% handles.r_in = r_in;
handles.car_delay = car_delay;
handles.green_min = green_min;
handles.FlashInd = FlashInd;
handles.ColorInd = ColorInd;

guidata(hObject,handles);


function numvert_Callback(hObject, eventdata, handles)
% hObject    handle to numvert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numvert as text
%        str2double(get(hObject,'String')) returns contents of numvert as a double

%      NQueues = str2double(get(handles.numvert,'String'));
%     %First select number of vertices.
%     %         axis off
%     % axis([-1.1,1.1,-1.1,1.1]);
%     hold on
%     for j=1:NQueues %positioning and labelling NQueues vertices
%         vertex= .95*[cos(j*2*pi/NQueues),sin(j*2*pi/NQueues)];
%         plot(vertex(1),vertex(2),'o','markersize',10)
%         name=.90*vertex;
%         text(name(1),name(2),int2str(j))
%     end

% --- Executes during object creation, after setting all properties.
function numvert_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numvert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in next.
function next_Callback(hObject, eventdata, handles)
% hObject    handle to next (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    global  quivertrack vertextrack MatrixFlow
    %I know global variables are 'bad' but getting rid of them is
    %complicated (switching back and forth between functions) so this is on
    %hold otherwise I wont get anything else done
    
    quivertrack = []; vertextrack = [];
    axes(handles.MainPlot);
    cla;
    ginput_log = [];

    NRows = handles.NumRows;
    NCols = handles.NumCols;
    
    NQueues = 4*NRows*NCols;
    MatrixFlow=zeros(NQueues,NQueues);
    
    hold on
    handles.NodePoints = streetgrid_plot( [NRows,NCols], 1, 1 );

    x=2;
    y=2;
    righton1=0;
    righton2=0;
    
    handles.done = 0;
    guidata(hObject,handles);
    
    while ~(handles.done)
        
        [x,y]=ginput(2);
        ginput_log = cat(1,[x,y], ginput_log);
        
        for j=1:NQueues
            if (abs(handles.NodePoints(j,1)-x(1))<1) && (abs(handles.NodePoints(j,2)-y(1))<1)
                x(1)=handles.NodePoints(j,1);
                y(1)=handles.NodePoints(j,2);
                righton1=1;
                vertex1=j;
            end
            
            if (abs(handles.NodePoints(j,1)-x(2))<1) && (abs(handles.NodePoints(j,2)-y(2))<1)
                x(2)=handles.NodePoints(j,1);
                y(2)=handles.NodePoints(j,2);
                righton2=1;
                vertex2=j;
            end
        end
        
        if (righton1==1)&&(righton2==1)

            tail=[x(1);y(1)];
            head=[x(2);y(2)];
            arrow=head-tail;
            
            last_arrow = quiver(x(1),y(1),arrow(1),arrow(2),0);
            quivertrack = cat(1,last_arrow, quivertrack);
            vertextrack = cat(1, [vertex2, vertex1,],vertextrack);
            MatrixFlow(vertex2,vertex1)=1;
            
            righton1=0;
            righton2=0;

        end
        
          drawnow; %continuing the 'done' button components
          handles = guidata(hObject);
          
        end
        hold off
        guidata(hObject,handles);

        
%         set(0,'showhiddenhandles','on'); % Make the GUI figure handle visible
%         h = findobj(gcf,'type','axes'); % Find the axes object in the GUI
%         f1 = figure; % Open a new figure with handle f1
%         s = copyobj(h,f1); % Copy axes object h into figure f1
        
        
% --- Executes on button press in done.
function done_Callback(hObject, eventdata, handles)
% hObject    handle to done (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    
    global MatrixFlow
    axes(handles.SidePlot);
    cla;
    %     m = str2double(get(handles.Nrows,'String'));
    %     n = str2double(get(handles.Ncols,'String'));
    NRows = handles.NumRows;
    NCols = handles.NumCols;
    StreetDim = [NRows,NCols];
    Emat = handles.Emat;
    
    hold on
    NodePoints = streetgrid_plot( StreetDim, 1, 0 );
    plot_graph( MatrixFlow, NodePoints )
    hold off
    A = MatrixFlow + MatrixFlow';
    handles.A = A;

    handles.done = 1;
    guidata(hObject,handles);


% --- Executes on button press in delete.
function delete_Callback(hObject, eventdata, handles)
% hObject    handle to delete (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global quivertrack vertextrack MatrixFlow

    delete(quivertrack(1,1:end));
    MatrixFlow(vertextrack(1,1), vertextrack(1,2)) = 0;
    vertextrack = vertextrack(2:end,:);
    quivertrack = quivertrack(2:end,:);
    
% --- Executes on selection change in graphselect.
function graphselect_Callback(hObject, eventdata, handles)
% hObject    handle to graphselect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns graphselect contents as cell array
%        contents{get(hObject,'Value')} returns selected item from graphselect

global MatrixFlow

set(handles.StopButton,'Userdata',0);

NRows = handles.NumRows;
NCols = handles.NumCols;

handles.NQueues = 4*NRows*NCols;
NQueues = handles.NQueues;
Emat = exit_mat([NRows,NCols]);

axes(handles.SidePlot);
hold on

content = get(hObject, 'Value');
guidata(hObject,handles);

switch content
    
    case 2
        %One-Step
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        MatrixFlow = one_step([NRows,NCols]);
        A = MatrixFlow + MatrixFlow';
        plot_graph( A, handles.NodePoints );
        handles.A = A;
        guidata(hObject,handles);

        
    case 3
        %Two-Step
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        MatrixFlow = one_step([NRows,NCols]);
        A = MatrixFlow^2 + (MatrixFlow')^2 + MatrixFlow + MatrixFlow';
        plot_graph( A, handles.NodePoints );
        handles.A = A;
        guidata(hObject,handles);


    case 4
        %directed one-step
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        MatrixFlow = one_step([NRows,NCols]);
        A = MatrixFlow';
        plot_graph( A, handles.NodePoints );
        handles.A = A;
        guidata(hObject,handles);
        

    case 5
        %directed two-step
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        MatrixFlow = one_step([NRows,NCols]);
        A = (MatrixFlow^2 + MatrixFlow)';
        plot_graph( A, handles.NodePoints );
        handles.A = A;
        guidata(hObject,handles);
        
    case 6
        %complete graph
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        MatrixFlow = ones(NQueues,NQueues) - eye(NQueues);
        A = MatrixFlow;
        plot_graph( A, handles.NodePoints );
        handles.A = A;
        guidata(hObject,handles);
        
    case 7
        % Add custom graph here.
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        [file,path]=uigetfile('adj*.mat');
        load(file);
        MatrixFlow = adj;
        A = MatrixFlow;
        plot_graph( A, handles.NodePoints );
        handles.A=A;
        guidata(hObject,handles);
        
    case 8
        
        cla;
        
        exitcat = cat(2,Emat,zeros(NRows+NCols,NRows+NCols));
        NodePoints = streetgrid_plot( [NRows,NCols], 1, 1 );
        handles.NodePoints = cat(1,NodePoints,zeros(NRows+NCols,2));
        NodePoints = handles.NodePoints;
        spec = ':k'; lw = 1; pensize = 10;
        for i = 1:(NRows+NCols)
            
            NodePoints(NQueues + i,:) = [10 + 5*i, 2];
            vertex = NodePoints(NQueues+i,:);
            plot(vertex(1), vertex(2),spec,'markersize',pensize);
            
        end
        
        MatrixFlow = cat(1, zeros(NQueues,NQueues+NRows+NCols), exitcat);
        plot_graph( MatrixFlow,NodePoints );
        handles.NodePoints = NodePoints;
        guidata(hObject,handles);

    case 9
        cla;
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        MatrixFlow = conflict([NRows,NCols]);
        
        PickConflict = handles.PickConflict;
        
        if PickConflict == 1

            MatrixFlow = conflict([NRows,NCols], handles.Ac);
            
        else
            
            MatrixFlow = SimpleConflict([NRows,NCols]);
            
        end
        
        plot_graph( MatrixFlow,handles.NodePoints );
        guidata(hObject,handles);
        
    case 10
        
        cla
        [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
        guidata(hObject,handles);

        
    otherwise
        
end

% guidata(hObject,handles);


%%Removes graph plot from GUI%%
% set(0,'showhiddenhandles','on'); % Make the GUI figure handle visible
% h = findobj(gcf,'type','axes'); % Find the axes object in the GUI
% f1 = figure; % Open a new figure with handle f1
% s = copyobj(h,f1); % Copy axes object h into figure f1

% --- Executes during object creation, after setting all properties.
function graphselect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to graphselect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    handles = guidata(hObject);
    set(hObject, 'min', 1);
    set(hObject, 'max', 15);
    sliderValue = floor(get(handles.slider1,'Value'));
    set(handles.disp_numvert,'String',num2str(sliderValue));

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in save_mat.
function save_mat_Callback(hObject, eventdata, handles)
% hObject    handle to save_mat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over popupmenu2.
function popupmenu2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over numvert.
function numvert_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to numvert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function Nrows_Callback(hObject, eventdata, handles)
% hObject    handle to Nrows (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Nrows as text
%        str2double(get(hObject,'String')) returns contents of Nrows as a double


NRows = str2double(get(hObject,'String'));
handles.NumRows = NRows;

guidata(hObject,handles);
%%Below is what used to be in this callback

% set(handles.StopButton,'Userdata',0);
% 
% NRows = str2double(get(hObject,'String'));
% NCols = handles.NumCols;
% StreetDim = [NRows, NCols];
% NQueues = 4*NRows*NCols;
% PickConflict = handles.PickConflict;
% 
% DirMat = QueuePlotDirection( StreetDim );
% Emat = exit_mat( StreetDim );
% FlowIndMat = FindFlowMatInd( StreetDim, handles.CompSwap );
% Af01 = one_step( StreetDim );
% Af = [MakeStochastic( Af01, FlowIndMat ) zeros(NQueues,NRows+NCols);...
%     Emat, zeros(NRows+NCols,NRows+NCols)];
% 
% A = Af01 + Af01';
% 
% if PickConflict == 1
%     
%     %This is the original conflict scheme
%     Ac = [conflict( StreetDim ) zeros(NQueues, NRows + NCols);...
%         zeros(NRows + NCols, NQueues + NRows + NCols)];
%     %Random light arrangement
%     ColorVec = RandLight( StreetDim, Ac );
%     
% else
%     
%     %This scheme treats each light pair as a unit
%     Ac = [SimpleConflict( StreetDim ) zros(NQueues, NRows + NCols);...
%         zeros(NRows + NCols, NQueues + NRows + NCols)];
%     %Random light arrangement
%     ColorVec = SimpleRandLight( StreetDim );
% 
% end
% 
% QVecMin = .5 + 2.5*rand(NQueues,1); 
% QVecMax = 3 + 6*rand(NQueues,1);
% QVec = QVecMin;
% QnumHist = [];
% NodePoints = NodePointsData( StreetDim );
% [QStart, X, Y] = QData( NodePoints, QVec, DirMat );
% [Lightx, Lighty] = light_calc( NodePoints, StreetDim );
% 
% QInflowIndex = InitialInflowIndx( StreetDim );
% IniFlowRatio = handles.IniFlowRatio; %choose a method for finding an intial ratio for the inflow slider
% IQFlowmax = handles.IQFlowmax;
% IFidx = QInflowIndex( QInflowIndex~= EditQueue );
% 
% IFmaxDistrib = zeros(NQueues,1);
% IFmaxDistrib( QInflowIndex ) = .8 + rand(length(QInflowIndex),1)*(1 - .8);
% handles.IFmaxDistrib = IFmaxDistrib;
% QInflowRates = zeros(NQueues + NRows + NCols,1);
% QInflowRates( IFidx ) = IFmaxDistrib( IFidx ).*IQFlowmax*IniFlowRatio;
% QInflowRates( EditQueue ) = IQFlowmax*IniFlowRatio;
% handles.IFidx = IFidx;
% handles.QInflowRates = QInflowRates;
% handles.QInflowIndex = QInflowIndex;
% 
% % QInflowRates = zeros(NQueues + NRows + NCols,1); %REVISIT
% % QInflowRates( QInflowIndex ) = randi([100,200],length(QInflowIndex),1);
% % QInflowMin = QInflowRates;
% % r_in = (1/1800)*QInflowRates;
% car_delay = ones(NQueues,1);
% green_min = 3*ones(NQueues,1);
% 
% FlashInd = [ 1 1 0 ];
% ColorInd = 0;
% pause('off')
% 
% handles.NumRows = NRows;
% handles.StreetDim = StreetDim;
% handles.NQueues = NQueues;
% handles.DirMat = DirMat;
% handles.Af = Af;
% handles.Ac = Ac;
% handles.A = A;
% handles.Emat = Emat;
% handles.NodePoints = NodePoints;
% handles.QVecMin = QVecMin;
% handles.QVecMax = QVecMax;
% handles.QVec = QVec;
% handles.QnumHist = QnumHist;
% handles.QStart = QStart;
% handles.Lightx = Lightx;
% handles.Lighty = Lighty;
% handles.ColorVec = ColorVec;
% handles.QInflowIndex = QInflowIndex;
% % handles.QInflowRates = QInflowRates;
% % handles.QInflowMin = QInflowMin;
% % handles.r_in = r_in;
% handles.car_delay = car_delay;
% handles.green_min = green_min;
% handles.FlashInd = FlashInd;
% handles.ColorInd = ColorInd;
% 
% guidata(hObject,handles);
% %update plots below
% axes(handles.SidePlot);
% cla
% hold on
% [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
% plot_graph( A, handles.NodePoints );
% hold off
% 
% axes(handles.MainPlot);
% cla
% hold on
% NodePoints = streetgrid_plot( StreetDim, 0, 1 );
% handles = PlotQueues(handles);
% 
% % set(handles.IQbox,'string',QVec(EditQueue));
% % set(handles.IQslider,'value',QVec(EditQueue)/10);
% 
% for k=1:NQueues
%     % Draw green and red lights based on the value of QLights.
%     fieldname = sprintf('Light%d',k);
%     x = Lightx(:,k);
%     y = Lighty(:,k);
%     if ColorVec(k)==1
%         handles.(fieldname) = fill(x,y,'g');
%     else
%         handles.(fieldname) = fill(x,y,'r');
%     end
%     
% end
% drawnow
% hold off
% 
% guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function Nrows_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Nrows (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ncols_Callback(hObject, eventdata, handles)
% hObject    handle to Ncols (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ncols as text
%        str2double(get(hObject,'String')) returns contents of Ncols as a double


NCols = str2double(get(hObject,'String'));
handles.NumCols = NCols;

guidata(hObject,handles);
%%Below is what used to be in this callback

% set(handles.StopButton,'Userdata',0);
% 
% NCols = str2double(get(hObject,'String'));
% NRows = handles.NumRows;
% StreetDim = [NRows, NCols];
% NQueues = 4*NRows*NCols;
% PickConflict = handles.PickConflict;
% 
% DirMat = QueuePlotDirection( StreetDim );
% Emat = exit_mat( StreetDim );
% 
% FlowIndMat = FindFlowMatInd( StreetDim, handles.CompSwap );
% Af01 = one_step( StreetDim );
% Af = [MakeStochastic( Af01, FlowIndMat ) zeros(NQueues,NRows+NCols);...
%     Emat, zeros(NRows+NCols,NRows+NCols)];
% A = Af01 + Af01';
% 
% if PickConflict == 1
%     
%     %This is the original conflict scheme
%     Ac = [conflict( StreetDim ) zeros(NQueues, NRows + NCols);...
%         zeros(NRows + NCols, NQueues + NRows + NCols)];
%     %Random light arrangement
%     ColorVec = RandLight( StreetDim, Ac );
%     
% else
%     
%     %This scheme treats each light pair as a unit
%     Ac = [SimpleConflict( StreetDim ) zros(NQueues, NRows + NCols);...
%         zeros(NRows + NCols, NQueues + NRows + NCols)];
%     %Random light arrangement
%     ColorVec = SimpleRandLight( StreetDim );
% 
% end
% 
% QVecMin = .5 + 2.5*rand(NQueues,1); 
% QVecMax = 3 + 6*rand(NQueues,1);
% QVec = QVecMin;
% QnumHist = [];
% NodePoints = NodePointsData( StreetDim );
% [QStart, X, Y] = QData( NodePoints, QVec, DirMat );
% [Lightx, Lighty] = light_calc( NodePoints, StreetDim );
% 
% QInflowIndex = InitialInflowIndx( StreetDim );
% IniFlowRatio = handles.IniFlowRatio; %choose a method for finding an intial ratio for the inflow slider
% IQFlowmax = handles.IQFlowmax;
% IFidx = QInflowIndex( QInflowIndex~= EditQueue );
% 
% IFmaxDistrib = zeros(NQueues,1);
% IFmaxDistrib( QInflowIndex ) = .8 + rand(length(QInflowIndex),1)*(1 - .8);
% handles.IFmaxDistrib = IFmaxDistrib;
% QInflowRates = zeros(NQueues + NRows + NCols,1);
% QInflowRates( IFidx ) = IFmaxDistrib( IFidx ).*IQFlowmax*IniFlowRatio;
% QInflowRates( EditQueue ) = IQFlowmax*IniFlowRatio;
% handles.IFidx = IFidx;
% handles.QInflowRates = QInflowRates;
% handles.QInflowIndex = QInflowIndex;
% % QInflowRates = zeros(NQueues + NRows + NCols,1); %REVISIT
% % QInflowRates( QInflowIndex ) = randi([100,200],length(QInflowIndex),1);
% % QInflowMin = QInflowRates;
% % r_in = (1/1800)*QInflowRates;
% car_delay = ones(NQueues,1);
% green_min = 3*ones(NQueues,1);
% 
% FlashInd = [ 1 1 0 ];
% ColorInd = 0;
% pause('off')
% 
% handles.NumCols = NCols;
% handles.StreetDim = StreetDim;
% handles.NQueues = NQueues;
% handles.DirMat = DirMat;
% handles.Af = Af;
% handles.Ac = Ac;
% handles.A = A;
% handles.Emat = Emat;
% handles.NodePoints = NodePoints;
% handles.QVecMin = QVecMin;
% handles.QVecMax = QVecMax;
% handles.QVec = QVec;
% handles.QnumHist = QnumHist;
% handles.QStart = QStart;
% handles.Lightx = Lightx;
% handles.Lighty = Lighty;
% handles.ColorVec = ColorVec;
% handles.QInflowIndex = QInflowIndex;
% handles.QInflowRates = QInflowRates;
% % handles.QInflowMin = QInflowMin;
% % handles.r_in = r_in;
% handles.car_delay = car_delay;
% handles.green_min = green_min;
% handles.FlashInd = FlashInd;
% handles.ColorInd = ColorInd;
% 
% guidata(hObject,handles);
% %update plots below
% axes(handles.SidePlot);
% cla
% hold on
% [handles.NodePoints] = streetgrid_plot( [NRows,NCols], 1, 1 );
% plot_graph( A, handles.NodePoints );
% hold off
% 
% axes(handles.MainPlot);
% cla
% hold on
% NodePoints = streetgrid_plot( StreetDim, 0, 1 );
% handles = PlotQueues(handles);
% 
% % set(handles.IQbox,'string',QVec(EditQueue));
% % set(handles.IQslider,'value',QVec(EditQueue)/10);
% 
% for k=1:NQueues
%     % Draw green and red lights based on the value of QLights.
%     fieldname = sprintf('Light%d',k);
%     x = Lightx(:,k);
%     y = Lighty(:,k);
%     if ColorVec(k)==1
%         handles.(fieldname) = fill(x,y,'g');
%     else
%         handles.(fieldname) = fill(x,y,'r');
%     end
%     
% end
% drawnow
% hold off
% 
% guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function Ncols_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ncols (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function done_CreateFcn(hObject, eventdata, handles)
% hObject    handle to done (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on selection change in select_scenario.
% function select_scenario_Callback(hObject, eventdata, handles)
% % hObject    handle to select_scenario (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hints: contents = cellstr(get(hObject,'String')) returns select_scenario contents as cell array
% %        contents{get(hObject,'Value')} returns selected item from select_scenario
% %tag was 'select_scenario' for drop down menu

% axes(handles.SidePlot);
% cla;
% 
% set(handles.StopButton,'Userdata',0);
% 
% m = handles.NumRows;
% n = handles.NumCols;
% NQueues = handles.NQueues;
% EditQueue = handles.EditQueue;
% 
% StreetDim = [m,n];
% DirMat = QueuePlotDirection( StreetDim );
% handles.DirMat = DirMat;
% 
% hold on
% handles.NodePoints = streetgrid_plot( StreetDim, 1, 0 );
% plot_graph( handles.A, handles.NodePoints )
% hold off
% 
% axes(handles.MainPlot);
% hold on
% 
% [Lightx, Lighty] = light_calc( handles.NodePoints, [m,n] );
% 
% ColorVec = RandLight( [m,n], conflict([m,n]) );
% 
% % [handles.GreenFill, handles.RedFill] = light_plot( LightPoints, ColorVec );
% % handles.LightPoints = LightPoints;
% handles.Lightx = Lightx;
% handles.Lighty = Lighty;
% handles.ColorVec = ColorVec;
% 
% content = get(hObject, 'Value');
% 
% switch content
%     
%     case 2
%         
%         cla;
%         
%         NodePoints = streetgrid_plot( StreetDim, 0, 1 );
%         handles.NodePoints = NodePoints;
%         handles.QVec = .5 + 1.5*rand(NQueues,1);
%         QVec = handles.QVec;
%         handles = PlotQueues(handles);
%         
%         set(handles.IQbox,'string',QVec(EditQueue));
%         set(handles.IQslider,'value',QVec(EditQueue)/10);
%         
%         for k=1:NQueues
%             % Draw green and red lights based on the value of QLights.
%             fieldname = sprintf('Light%d',k);
%             x = Lightx(:,k);
%             y = Lighty(:,k);
%             if ColorVec(k)==1
%                 handles.(fieldname) = fill(x,y,'g');
%             else
%                 handles.(fieldname) = fill(x,y,'r');
%             end
%             
%         end
%         drawnow
%         
%         guidata(hObject,handles);
%         
%     case 3
%         
%         cla;
%         
%         handles.NodePoints = streetgrid_plot( StreetDim, 0, 1 );
%         handles.QVec = 2 + 5*rand(NQueues,1);
%         QVec = handles.QVec;
%         
%         [handles.QStart, handles.QFill] = QData( handles.NodePoints,handles.QVec, DirMat );
%         handles = PlotQueues(handles);
%         
%         set(handles.IQbox,'string',QVec(EditQueue));
%         set(handles.IQslider,'value',QVec(EditQueue)/10);
%         
%         for k=1:NQueues
%             % Draw green and red lights based on the value of QLights.
%             fieldname = sprintf('Light%d',k);
%             x = Lightx(:,k);
%             y = Lighty(:,k);
%             if ColorVec(k)==1
%                 handles.(fieldname) = fill(x,y,'g');
%             else
%                 handles.(fieldname) = fill(x,y,'r');
%             end
%             
%         end
%         drawnow
%         
%         guidata(hObject,handles);
%         
%     case 4
%         
%         cla;
%         
%         handles.NodePoints = streetgrid_plot( StreetDim, 0, 1 );
%         
%         Q = 5*rand(NQueues,1);
%         handles.QVec = 5*(exp(Q-2.5)./(1 + exp(Q-2.5))); %sigmoid function
%         QVec = handles.QVec;
%         
%         [handles.QStart, handles.QFill] = QData( handles.NodePoints,handles.QVec, DirMat );
%         handles = PlotQueues(handles);
%         
%         set(handles.IQbox,'string',QVec(EditQueue));
%         set(handles.IQslider,'value',QVec(EditQueue)/10);
%         
%         for k=1:NQueues
%             % Draw green and red lights based on the value of QLights.
%             fieldname = sprintf('Light%d',k);
%             x = Lightx(:,k);
%             y = Lighty(:,k);
%             if ColorVec(k)==1
%                 handles.(fieldname) = fill(x,y,'g');
%             else
%                 handles.(fieldname) = fill(x,y,'r');
%             end
%             
%         end
%         drawnow
%         
%         guidata(hObject,handles);
%         
%     otherwise
%         
%         
%         hold off
%         
% end

% --- Executes during object creation, after setting all properties.
function select_scenario_CreateFcn(hObject, eventdata, handles)
% hObject    handle to select_scenario (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_queue_Callback(hObject, eventdata, handles)
% hObject    handle to edit_queue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_queue as text
%        str2double(get(hObject,'String')) returns contents of edit_queue as a double

EditQueue = str2double(get(hObject, 'String')); 
handles.EditQueue = EditQueue;

IQmax = handles.IQmax;
IQFlowmax = handles.IQFlowmax;
MaxMinGreen = handles.MaxMinGreen;
MaxCarDelay = handles.MaxCarDelay;

green_min = handles.green_min;
QVec = handles.QVec;
% QInflowMin = handles.QInflowMin;
QInflowRates = handles.QInflowRates;
car_delay = handles.car_delay;

set(handles.IQbox, 'string', QVec(EditQueue));
set(handles.IQslider, 'value', QVec(EditQueue)/IQmax);

set(handles.IRbox,'string', QInflowRates( EditQueue ));
set(handles.IRslider,'value', QInflowRates( EditQueue )/IQFlowmax);

set(handles.MGbox,'string', green_min( EditQueue ));
set(handles.MGslider,'value', green_min( EditQueue )/MaxMinGreen);

set(handles.CDbox,'string',car_delay(EditQueue));
set(handles.CDslider,'value',car_delay(EditQueue)/MaxCarDelay);

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edit_queue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_queue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function IQslider_Callback(hObject, eventdata, handles)
% hObject    handle to IQslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


axes(handles.MainPlot)
% QFill = handles.QFill;
% delete(QFill)

% m = str2double(get(handles.Nrows,'String'));
% n = str2double(get(handles.Ncols,'String'));
m = handles.NumRows;
n = handles.NumCols;
StreetDim = [m,n];
Qnum = str2double(get(handles.edit_queue,'String'));
DirMat = handles.DirMat;
IQmax = handles.IQmax;
% Initital Queues are set to min of 0 and max of 10.
QLength=IQmax*get(hObject,'Value');
QText = num2str(QLength);
% Update the text to the left of the slider.
set(handles.IQbox,'String',QText);
% Redraw the new queue box with the upddated data.
QVecMin = handles.QVecMin;
QVec=handles.QVec;
QVec(Qnum) = QLength;
QVecMin(Qnum) = QLength;
handles.QVec = QVec;
handles.QVecMin = QVecMin;

QStart = handles.QStart;

QnumHist = handles.QnumHist;

QnumHist = unique( [QnumHist, Qnum] );
handles.QnumHist = QnumHist;

% N = 4*n*m;
% QVec( setdiff([1:4*n*m], QnumHist) )

UpdateQueues( handles )

guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function IQslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IQslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



% --- Executes on slider movement.
function IRslider_Callback(hObject, eventdata, handles)
% hObject    handle to IRslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

EditQueue = handles.EditQueue;
QInflowRates = handles.QInflowRates;
IQFlowmax = handles.IQFlowmax;

% r_in = handles.r_in;

a = IQFlowmax*get(hObject,'Value');

QInflowRates( EditQueue ) = a;

% r_in( EditQueue ) = (1/1800)*a;

set(handles.IRbox,'string', a);

handles.QInflowRates = QInflowRates;

IFidx = handles.IFidx;
IFidx = IFidx( IFidx ~= EditQueue );
handles.IFidx = IFidx;
% handles.r_in = r_in;

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function IRslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IRslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function MGslider_Callback(hObject, eventdata, handles)
% hObject    handle to MGslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

EditQueue = handles.EditQueue;
MaxMinGreen = handles.MaxMinGreen;
green_min = handles.green_min;

a = MaxMinGreen*get(hObject,'Value');
green_min( EditQueue ) = a;

set(handles.MGbox,'string',a);

handles.green_min = green_min;

guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function MGslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MGslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function CDslider_Callback(hObject, eventdata, handles)
% hObject    handle to CDslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

EditQueue = handles.EditQueue;
MaxCarDelay = handles.MaxCarDelay;
car_delay = handles.car_delay;

a = MaxCarDelay*get(hObject,'Value');
car_delay( EditQueue ) = a;

set(handles.CDbox,'string',a);

handles.car_delay = car_delay;

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function CDslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CDslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function IQbox_Callback(hObject, eventdata, handles)
% hObject    handle to IQbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IQbox as text
%        str2double(get(hObject,'String')) returns contents of IQbox as a double

EditQueue = handles.EditQueue;
QVec = handles.QVec;
IQmax = handles.IQmax;

BoxUpdate = str2double(get(hObject,'String'));
QVec( EditQueue ) = BoxUpdate;
set(handles.IQbox,'string',BoxUpdate);
set(handles.IQslider,'value',BoxUpdate/IQmax);

handles.QVec = QVec;
UpdateQueues( handles )

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function IQbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IQbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function IRbox_Callback(hObject, eventdata, handles)
% hObject    handle to IRbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IRbox as text
%        str2double(get(hObject,'String')) returns contents of IRbox as a double


EditQueue = handles.EditQueue;
% QVec = handles.QVec;
IQFlowmax = handles.IQFlowmax;
QInflowRates = handles.QInflowRates;
% r_in = handles.r_in;

BoxUpdate = str2double(get(hObject,'String'));
QInflowRates( EditQueue ) = BoxUpdate;
% r_in( EditQueue ) = (1/1800)*BoxUpdate;
set(handles.IRbox,'string',BoxUpdate);
set(handles.IRslider,'value',BoxUpdate/IQFlowmax);

handles.QInflowRates = QInflowRates;
% handles.r_in = r_in;

IFidx = handles.IFidx;
IFidx = IFidx( IFidx ~= EditQueue );
handles.IFidx = IFidx;
% 
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function IRbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IRbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MGbox_Callback(hObject, eventdata, handles)
% hObject    handle to MGbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MGbox as text
%        str2double(get(hObject,'String')) returns contents of MGbox as a double

EditQueue = handles.EditQueue;
MaxMinGreen = handles.MaxMinGreen;
green_min = handles.green_min;

BoxUpdate = str2double(get(hObject,'String'));
green_min( EditQueue ) = BoxUpdate;

set(handles.MGbox,'string',BoxUpdate);
set(handles.MGslider,'value',BoxUpdate/MaxMinGreen);

handles.green_min = green_min;

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function MGbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MGbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CDbox_Callback(hObject, eventdata, handles)
% hObject    handle to CDbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CDbox as text
%        str2double(get(hObject,'String')) returns contents of CDbox as a double
EditQueue = handles.EditQueue;
MaxCarDelay = handles.MaxCarDelay;
car_delay = handles.car_delay;

BoxUpdate = str2double(get(hObject,'String'));
car_delay( EditQueue ) = BoxUpdate;

set(handles.CDbox,'string',BoxUpdate);
set(handles.CDslider,'value',BoxUpdate/MaxCarDelay);

handles.car_delay = car_delay;

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function CDbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CDbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function IterCounter_Callback(hObject, eventdata, handles)
% hObject    handle to IterCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IterCounter as text
%        str2double(get(hObject,'String')) returns contents of IterCounter as a double


% --- Executes during object creation, after setting all properties.
function IterCounter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IterCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SimuToggle.
function SimuToggle_Callback(hObject, eventdata, handles)
% hObject    handle to SimuToggle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of SimuToggle
button_state = get(hObject,'Value');
if button_state == get(hObject,'Min')
    set(handles.SimuToggle,'string','Consensus','BackgroundColor',[0.9,0.7,0]);
elseif button_state == get(hObject,'Max')
	set(handles.SimuToggle,'string','Proportional','BackgroundColor',[0,0.8,1]);
end
uiresume;






% --- Executes on selection change in IFselect.
function IFselect_Callback(hObject, eventdata, handles)
% hObject    handle to IFselect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns IFselect contents as cell array
%        contents{get(hObject,'Value')} returns selected item from IFselect

NRows = handles.NumRows;
NCols = handles.NumCols;
NQueues = handles.NQueues;
M = NQueues/2;

QInflowIndex = handles.QInflowIndex;
QInflowRates = handles.QInflowRates;
% QInflowRates = zeros(NQueues + NRows + NCols,1);

content = get(hObject, 'Value');

switch content
    
    case 2
        
        %These inflow rates assignments should not be necessary since they
        %have been moved to inside the main run itertion
%         Q = QInflowRates([1 2 M+1 M+2]);
%         QInflowRates = zeros(NQueues + NRows + NCols,1);
%         QInflowRates([1 2 M+1 M+2]) = Q;
%         r_in = (1/1800)*QInflowRates;
%         handles.QInflowRates = QInflowRates;
%         handles.r_in = r_in;

        %this part is definitely necessary
        QInflowIndex = [1 2 M+1 M+2];
        QInflowRates( setdiff([1:NQueues], QInflowIndex ) ) = 0;
        
        handles.QInflowIndex = QInflowIndex;
        handles.QInflowRates = QInflowRates;
        guidata(hObject,handles);

    case 3
        
        %Add more cases here
        
        
    otherwise
        
        
end

guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function IFselect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IFselect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function QSizeslide_Callback(hObject, eventdata, handles)
% hObject    handle to QSizeslide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
axes(handles.MainPlot)

m = handles.NumRows;
n = handles.NumCols;
Qnum = str2double(get(handles.edit_queue,'String'));

QVecMin = handles.QVecMin;
QVecMax = handles.QVecMax;
QVec=handles.QVec;
StreetDim = [m,n];
DirMat = handles.DirMat;
IQmax = handles.IQmax;
QnumHist = handles.QnumHist;
% Initital Queues are set to min of 0 and max of 10.
% QLength=IQmax*get(hObject,'Value');
% QText = num2str(QLength);

% Redraw the new queue box with the updated data.
% QVec(Qnum) = QLength;

ratio = get(hObject,'Value');
%This makes the 'traffic selection' slider and 'queue parameters' sliders
%independent
QnumHist = unique( [QnumHist, Qnum] );
N = 4*n*m;
QVec( setdiff([1:N], QnumHist) ) = min((abs(QVecMax( setdiff([1:N], QnumHist) ) - QVecMin( setdiff([1:N], QnumHist) )))*...
    ratio + QVecMin( setdiff([1:N], QnumHist) ), IQmax);

handles.QVec = QVec;
handles.QnumHist = QnumHist;

% Update the other queue slider.
% set(handles.IQslider,'value',QVec(Qnum)/IQmax);
% set(handles.IQbox,'String', num2str(QVec(Qnum)));
set(handles.QSizebox,'String',ratio);

QStart = handles.QStart;
% fieldname = sprintf('Queue%d',Qnum);
% xq = handles.(fieldname);

UpdateQueues( handles )

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function QSizeslide_CreateFcn(hObject, eventdata, handles)
% hObject    handle to QSizeslide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function IFSizeslide_Callback(hObject, eventdata, handles)
% hObject    handle to IFSizeslide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% 
% axes(handles.MainPlot)
% 
% m = handles.NumRows;
% n = handles.NumCols;
% IQFlowmax = handles.IQFlowmax;
% Qnum = str2double(get(handles.edit_queue,'String'));
% QInflowMin = handles.QInflowMin;
% 
% 
% % Initital Queues are set to min of 0 and max of 10.
% % QLength=IQmax*get(hObject,'Value');
% % QText = num2str(QLength);
% 
% % Redraw the new queue box with the upddated data.
% % QVec(Qnum) = QLength;
% 
% NQueues=handles.NQueues;
% 
% QStart = handles.QStart;
% % fieldname = sprintf('Queue%d',Qnum);
% % xq = handles.(fieldname);
% %
% %
% % Adjust the inflow rates on the fly.
% 
% QInflowIndex=handles.QInflowIndex;
% IFidx = QInflowIndex( QInflowIndex~= Qnum );
% 
ratio=get(hObject,'Value');
% QInflowRates = zeros(NQueues + m + n,1); %REVISIT
% % QInflowRates( QInflowIndex ) = 1000*ratio*randi([100,200],length(QInflowIndex),1);
% % QInflowRates( QInflowIndex ) = min( abs( IQFlowmax - QInflowMin( QInflowIndex ) )*ratio + QInflowMin( QInflowIndex ), IQFlowmax );
% X0 = -QInflowMin( IFidx )./( IQFlowmax - QInflowMin( IFidx ) );
% QInflowRates( IFidx ) = min( abs( IQFlowmax - QInflowMin( IFidx ) ).*...
%     ((1-X0)*ratio + X0) + QInflowMin( IFidx ), IQFlowmax );
% r_in = (1/1800)*QInflowRates;
% handles.r_in = r_in;

% Update the other queue slider.
% set(handles.IRslider,'value',QInflowRates(Qnum)/IQFlowmax);
% set(handles.IRbox,'string',num2str(QInflowRates(Qnum)));
set(handles.IFSizebox,'string',ratio);

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function IFSizeslide_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IFSizeslide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function QSizebox_Callback(hObject, eventdata, handles)
% hObject    handle to QSizebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of QSizebox as text
%        str2double(get(hObject,'String')) returns contents of QSizebox as a double


BoxUpdate = str2double(get(hObject,'String'));
set(handles.QSizebox,'string',BoxUpdate);
set(handles.QSizeslide,'value',BoxUpdate);

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function QSizebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to QSizebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function IFSizebox_Callback(hObject, eventdata, handles)
% hObject    handle to IFSizebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IFSizebox as text
%        str2double(get(hObject,'String')) returns contents of IFSizebox as a double

BoxUpdate = str2double(get(hObject,'String'));
set(handles.IFSizebox,'string',BoxUpdate);
set(handles.IFSizeslide,'value',BoxUpdate);

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function IFSizebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IFSizebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function uibuttongroup5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uibuttongroup5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in SaveButton.
function SaveButton_Callback(hObject, eventdata, handles)
% hObject    handle to SaveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%used to change the SaveFlag in RunButton while stopped or at end of the
% simulation so that it saves y, yf, green A, Af, and Ac.  
savetest=get(handles.SaveButton,'UserData');
if savetest ==0
    set(handles.SaveButton,'UserData', 1)
%else   
%    set(handles.SaveButton,'UserData', 0)
end
uiresume;



function CarCounter_Callback(hObject, eventdata, handles)
% hObject    handle to CarCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CarCounter as text
%        str2double(get(hObject,'String')) returns contents of CarCounter as a double


% --- Executes during object creation, after setting all properties.
function CarCounter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CarCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadData.
function loadData_Callback(hObject, eventdata, handles)
% hObject    handle to loadData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uiresume;
loadtest=get(handles.loadData,'UserData');
if loadtest ==0
    [file,path] = uigetfile('*.mat');
    set(handles.loadData,'UserData', 1)
    set(handles.loadData,'string','Data Loaded','BackgroundColor',[0,0.8,1]);
    handles.loadData1=file;
    load(file)
    NRows = handles.NumRows;
    NCols = handles.NumCols;
    NQueues = 4*NRows*NCols;
    SimuFlag = get(handles.SimuToggle,'Value');
    if SimuFlag == 0
      handles.QVec= y(1:NQueues,1);
      handles.ColorVec = green(1:NQueues,1);
      guidata(hObject, handles);
    else
      handles.QVec= yf(1:NQueues,1);
      handles.ColorVec = fgreen(1:NQueues,1);
      guidata(hObject, handles);
    end
    guidata(hObject, handles);
else   
    set(handles.loadData,'UserData', 0)
    set(handles.loadData,'string','Load Data','BackgroundColor',[0.9,0.7,0]);
end
uiwait


% --- Executes on selection change in DataSelect.
function DataSelect_Callback(hObject, eventdata, handles)
% hObject    handle to DataSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns DataSelect contents as cell array
%        contents{get(hObject,'Value')} returns selected item from DataSelect


% --- Executes during object creation, after setting all properties.
function DataSelect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DataSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function fCarCounter_Callback(hObject, eventdata, handles)
% hObject    handle to fCarCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fCarCounter as text
%        str2double(get(hObject,'String')) returns contents of fCarCounter as a double


% --- Executes during object creation, after setting all properties.
function fCarCounter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fCarCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function propslider_Callback(hObject, eventdata, handles)
% hObject    handle to propslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
propRatio=get(hObject,'Value');
set(handles.propbox,'string',propRatio);


% --- Executes during object creation, after setting all properties.
function propslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to propslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
% Setting step sizes as 1/12th
maxValue = get(hObject, 'Max');
minValue = get(hObject, 'Min');
Range = maxValue - minValue;
stepsize = [Range/12, Range/12];
set(hObject, 'SliderStep', stepsize);



function propbox_Callback(hObject, eventdata, handles)
% hObject    handle to propbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of propbox as text
%        str2double(get(hObject,'String')) returns contents of propbox as a double
propBoxUpdate = str2double(get(hObject,'String'));
set(handles.propbox,'string',propBoxUpdate);
set(handles.propslider,'value',propBoxUpdate);

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function propbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to propbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EWIFbox_Callback(hObject, eventdata, handles)
% hObject    handle to EWIFbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EWIFbox as text
%        str2double(get(hObject,'String')) returns contents of EWIFbox as a double
EWIFBoxUpdate = str2double(get(hObject,'String'));
set(handles.EWIFbox,'string',EWIFBoxUpdate);
set(handles.EWIFslider,'value',EWIFBoxUpdate);

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function EWIFbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EWIFbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NSIFbox_Callback(hObject, eventdata, handles)
% hObject    handle to NSIFbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NSIFbox as text
%        str2double(get(hObject,'String')) returns contents of NSIFbox as a double
NSIFBoxUpdate = str2double(get(hObject,'String'));
set(handles.NSIFbox,'string',NSIFBoxUpdate);
set(handles.NSIFslider,'value',NSIFBoxUpdate);

guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function NSIFbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NSIFbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function EWIFslider_Callback(hObject, eventdata, handles)
% hObject    handle to EWIFslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
EWIFBoxUpdate=get(hObject,'Value');
set(handles.EWIFbox,'string',EWIFBoxUpdate);
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function EWIFslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EWIFslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
% Setting step sizes as 1/12th
maxValue = get(hObject, 'Max');
minValue = get(hObject, 'Min');
Range = maxValue - minValue;
stepsize = [Range/12, Range/12];
set(hObject, 'SliderStep', stepsize);


% --- Executes on slider movement.
function NSIFslider_Callback(hObject, eventdata, handles)
% hObject    handle to NSIFslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
NSIFBoxUpdate = get(hObject,'Value');
set(handles.NSIFbox,'string',NSIFBoxUpdate);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function NSIFslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NSIFslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
% Setting step sizes as 1/12th
maxValue = get(hObject, 'Max');
minValue = get(hObject, 'Min');
Range = maxValue - minValue;
stepsize = [Range/12, Range/12];
set(hObject, 'SliderStep', stepsize);


% --- Executes on button press in IFNoiseCheckBox.
function IFNoiseCheckBox_Callback(hObject, eventdata, handles)
% hObject    handle to IFNoiseCheckBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of IFNoiseCheckBox
IFNoiseCheckUpdate=get(hObject,'Value');
set(handles.IFNoiseCheckBox,'value',IFNoiseCheckUpdate);


% --- Executes on button press in EWNSIFCheckBox.
function EWNSIFCheckBox_Callback(hObject, eventdata, handles)
% hObject    handle to EWNSIFCheckBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of EWNSIFCheckBox
EWNSIFCheckUpdate=get(hObject,'Value');
set(handles.EWNSIFCheckBox,'value',EWNSIFCheckUpdate);


% --- Executes during object creation, after setting all properties.
function SimuToggle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SimuToggle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
