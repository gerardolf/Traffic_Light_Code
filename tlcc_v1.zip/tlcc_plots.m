% tlcc_plots.m
%
% Generated plots for analysis of a previously generated run.
%
[file,path]=uigetfile('tlccData*.mat');
[pathstr,name,ext]=fileparts([path,'\',file]);
load(file);
% For now we assume all tuns are for 1200 iterations.
Runs=1200;
ymax=max(max(y));
yfmax=max(max(yf));
ym=max(ymax,yfmax);
stdy=std(y);
stdyf=std(yf);
stdmax=max(max(stdy),max(stdyf));
meanmax=max(max(mean(y)),max(mean(yf)));
subplot(3,2,1);
plot(y')
axis([0,Runs,0,ym])
title('Length of consensus queues')
subplot(3,2,2)
plot(yf')
axis([0,Runs,0,ym])
title('Length of proportional queues')
subplot(3,2,3)
plot(stdy)
axis([0,Runs,0,stdmax])
title('Consensus std')
subplot(3,2,4)
plot(stdyf)
axis([0,Runs,0,stdmax])
title('Proportional std')
subplot(3,2,5)
plot(mean(y))
axis([0,Runs,0,meanmax])
title('Mean queue Length (C)')
subplot(3,2,6)
plot(mean(yf))
axis([0,Runs,0,meanmax])
title('Mean queue Length (P)')
shg
% Prepare to save the figure window to a file for reporting.  Here the
% dafult is color encapsulated postcript.  Chek the MATLAB help for
% 'saveas' for more options.
filename=['plots_',name,];
% saveas(gcf,filename,'epsc');
% disp(['Plots saved in file ', filename,'.eps'])
% If you prefer saving in pdf format use the two lines below instead.
saveas(gcf,filename,'pdf');
disp(['Plots saved in file ', filename,'.pdf'])


      