function [Exit] = exit_mat( StreetDim )
%computes the exit flow matrix given street dimensions
%each street has one exit 'node', despite the two lanes
%this only provides the BLOCK for the exit matrix, so the dimensions given
%are technically not accurate. The true exit matrix will be
%   [0_{NxN | 0_{Nx(m+n)};
%   Exit_{m+n}xN | 0_{m+n}x{m+n}]

%NEWEST APPROACH
%Intuitive idea is the following: Exit indices are ordered according to
%which ones are reached first when looping over 1:NQueues. These nodes are
%stored in order, then we match them with the remaining node that
%corresponds to the same exit.
Af = one_step(StreetDim);
Ac = conflict(StreetDim);
m = StreetDim(1); n = StreetDim(2); N = 4*m*n; M = N/2;
dimsum = m + n;

Exit = zeros(dimsum,N);
ExitIdx = [];
ExitPair = zeros(n+m, 2);

%first we find all nodes going into exits
for i = 1:m
   
    idx = ((i-1)*2*n+1):2*n*i; %nodes along the ith row
    ExitIdx = [ExitIdx, idx( sum(Af(:,idx)) == 0 )];
  
end

for i = 1:n
   
    idx = [(M+1+2*(i-1)):2*n:(M+1+2*(i-1)+2*n*(m-1)),... 
        (M+1+2*(i-1))+1:2*n:(M+1+2*(i-1)+2*n*(m-1))+1]; %nodes along ith col
    ExitIdx = [ExitIdx, idx( sum(Af(:,idx)) == 0 )];
    
end

%pair off these nodes
j = 1;
for i = 1:2*(n+m)
    ExitIdx(i);
    MatchIdx = find( Ac(:,ExitIdx(i)) );
    
    if length( MatchIdx ) == 1
        
        ExitPair(j,[1,2] ) = [ExitIdx(i), MatchIdx];
        j = j+1;
        
    end
end

%assign values to exit matrix
for i = 1:n+m
   
    Exit(i, ExitPair(i,:)) = [ 1 1 ];
    
end


%OLD APPROACH
%{
dim1 = StreetDim(1); dim2 = StreetDim(2); N = 4*dim1*dim2; M = N/2;
dimsum = dim1 + dim2;

rw1 = ceil(dim1/2); rw2 = dim1 - rw1;
cl1 = ceil(dim2/2); cl2 = dim2 - cl1;
Exit = zeros(dimsum,N);

%THROUGH-LANES
%uses a linear index
%WE/EW exits
lin_start = (2*dim2-2)*(dimsum)+1;
inc = (4*dim2)*(dimsum) + 2;
lin_stop = (2*dim2-1)*(dimsum) + (ceil(dim1/2) - 1)*(4*dim2)*(dimsum);


if mod(dim2,2) ~= 0
    
    %WE exits 
    Exit( lin_start: inc: lin_stop ) = 1;
    
    if dim1 > 1
        
        %EW exits 
        Exit( lin_start + 2*dimsum + 1: inc: lin_stop + 2*dimsum ) = 1;
        
    end
    
else
    
    %WE exits 
    Exit( lin_start + dimsum: inc: lin_stop + dimsum ) = 1;
    
    if dim1 > 1
        
        %EW exits 
        Exit( lin_start + 2*dimsum + 1: inc: lin_stop + dimsum ) = 1;
        
    end
    
end

%NS/SN exits

%NS exits 
lin_start = (M + 2*dim2*(dim1-1) )*dimsum + dim1 + 1;
inc = 4*dimsum + 2;
lin_stop = (M + 1 + 2*dim2*(dim1-1))*dimsum + (ceil(dim2/2)-1)*4*dimsum;
if mod(dim1,2) ~= 0

    Exit( lin_start: inc: lin_stop ) = 1;

else
    
    Exit( lin_start + dimsum: inc: lin_stop + dimsum ) = 1;

end

%SN exits 
if dim2 > 1
    
    lin_start = (M + 2)*dimsum + dim1 + 2;
    inc = 4*dimsum + 2;
    lin_stop = (M + 3)*dimsum + (floor(dim2/2)-1)*4*dimsum;
    
    Exit( lin_start: inc: lin_stop ) = 1;
    
end


%
%TURN-LANES
%for turns from first row into SN exits ?
if dim2 > 1
    
    lin_start = (2*(dimsum) + dim1+2);
    inc = (4*(dimsum) + 2);
    lin_stop = 3*(dimsum)+(floor(dim2/2)-1)*4*(dimsum);
    Exit( lin_start: inc: lin_stop ) = 1;
    
end

%for turns from the last row into NS exits 
lin_start = (2*(dim1-1)*dim2+1)*(dimsum) + dim1+1;
inc = (4*(dimsum) + 2); 
lin_stop = lin_start + (ceil(dim2/2)-1)*inc;
Exit( lin_start: inc: lin_stop ) = 1;

%for turns from columns into EW/WE exits
lin_start = (M+(2*dim2-1))*dimsum + 1;
inc = 4*dim2*dimsum + 2;
lin_stop = (M+2*dim2)*dimsum + (ceil(dim1/2)-1)*4*dim2*dimsum;

%WE exits 
Exit( lin_start: inc: lin_stop ) = 1;

%EW exits 
lin_stop = (M+2*dim2 + 1)*dimsum  + (floor(dim1/2)-1)*4*dim2*dimsum;
Exit( lin_start + dimsum + 1: inc: lin_stop ) = 1;
%}

%{
%Should go back and check the indices. The above code works for most cases,
%but some tricky ones arose e.g. StreetDim = [3,3]
%This last section 'filters' out any miscounted indices
ExitCheck = sum(Exit');
CheckInd = find( ExitCheck > 2 );
if ~isempty( CheckInd )
    
    Flow = one_step(StreetDim);
    
    for i = 1:length( CheckInd )
        
        ExitInd = find( Exit( CheckInd(i), : ) );
        
        for j = 1:length(ExitInd)
            
            if sum( Flow( :, ExitInd( j ) ) ) ~= 0
                
                Exit( CheckInd(i), ExitInd(j) ) = 0;
                
            end
            
        end
        
    end
    
end

end
%}