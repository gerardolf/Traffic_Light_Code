function A_c = conflict( StreetDim )
%given the street dimensions, function outputs conflict matrix. We assume
%each node has its own light, allows for simulatenous turning

m = StreetDim(1); n = StreetDim(2); N = 4*m*n; M = N/2;

%the basic 'blocks' that appear in the conflic matrix
a = [1 1; 1 0]; b = [1 1; 0 1]; c = [1 0; 1 1]; d = [0 1; 1 1];

%accounts for 'alternating' behaviour accross the NS/SN streets
A = diag(toeplitz(mod(1:n,2),1));
B = toeplitz(mod(1:(n+1),2),1); B = B(2:end); B = diag(B);

%accounts for multiple WE/EW streets
rep_mat1 = diag(toeplitz(mod(1:m,2),1));
rm2 = toeplitz(mod(1:(m+1),2),1); rm2 = rm2(2:end); rep_mat2 = diag(rm2);

%combines the basic patterns with the alternating behaviour
conflict1_EW = kron(A,a); conflict1_WE = kron(A,c);
conflict2_EW = kron(B,b); conflict2_WE = kron(B,d);
conflict_EW = conflict1_EW + conflict2_EW;
conflict_WE = conflict1_WE + conflict2_WE;

%applies the above combinations to each row as appropriate
conflict1_total = kron(rep_mat1, conflict_EW);
conflict2_total = kron(rep_mat2, conflict_WE);
conflict_total = conflict1_total + conflict2_total;

%fills in the conflict matrix
A_c = [zeros(M), conflict_total'; conflict_total, zeros(M)];

end