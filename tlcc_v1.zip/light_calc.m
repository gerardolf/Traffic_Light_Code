function [ Lightx, Lighty ] = light_calc( NodePoints, StreetDim )

np = NodePoints;

dim1 = StreetDim(1); dim2 = StreetDim(2);
N = 4*dim1*dim2; M = N/2;
% light_points = zeros(N,5);
Lightx = zeros( 3, N );
Lighty = Lightx;

for i = 1:dim1
    
    for j = 1:(2*dim2)
        
        ind = j+(i-1)*(2*dim2);
        point = np(ind,:);
        
        x_crd1 = point(1)+5.25*(-1)^(i+1);
        x_crd2 = x_crd1 + .5*(-1)^(i+1);
        
        y_crd1 = point(2) - .5;
        y_crd2 = point(2) + .5;
        y_crd3 = point(2);

%         light_points(ind,:) = [ x_crd1 x_crd2 y_crd1 y_crd2 y_crd3 ];
        Lightx( :, ind ) = [ x_crd1; x_crd1; x_crd2 ];
        Lighty( :, ind ) = [ y_crd1; y_crd2; y_crd3 ];
        
    end
    
end

for i = 1:dim2
    
    for j = 1:dim1
        
        ind1 = M+1 + 2*(i-1) + (2*dim2)*(j-1);
        ind2 = ind1 + 1;
        point1 = np(ind1,:);
        point2 = np(ind2,:);
        
        x_pt11 = point1(1) + .5;
        x_pt12 = point1(1) - .5;
        x_pt13 = point1(1);
        
        y_pt11 = point1(2) + 5.25*(-1)^i;
        y_pt12 = y_pt11 + .5*(-1)^i;
        
        x_pt21 = point2(1) + .5;
        x_pt22 = point2(1) - .5;
        x_pt23 = point2(1);
        
        y_pt21 = point2(2) + 5.25*(-1)^i;
        y_pt22 = y_pt21 + .5*(-1)^i;
      
%         light_points(ind1,:) = [ x_pt11 x_pt12 x_pt13 y_pt11 y_pt12 ];
%         light_points(ind2,:) = [ x_pt21 x_pt22 x_pt23 y_pt21 y_pt21 ];
        Lightx( :, ind1 ) = [ x_pt11; x_pt12; x_pt13 ];
        Lighty( :, ind1 ) = [ y_pt11; y_pt11; y_pt12 ];
        Lightx( :, ind2 ) = [ x_pt21; x_pt22; x_pt23 ];
        Lighty( :, ind2 ) = [ y_pt21; y_pt21; y_pt22 ];
        
    end
    
end

end