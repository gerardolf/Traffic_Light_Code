function QInflowIndex = InitialInflowIndx( StreetDim )
%Finds the indices that correspond to the queues with a non-zero intial
%inflow rate i.e. the indices that are on the 'outside' of the grid
%Note that in other parts of the code QInflowIndex is used as an Nx1 vector
%containing all the indices that the user wants to have nonzero initial
%inflow rate e.g. QInflowIndex = [ 1 2 ] for just inflow at nodes 1 and 2.

m = StreetDim(1);
n = StreetDim(2);
M = 2*m*n;
QInflowIndex = zeros(2*(m+n), 1);

%loops over WE/EW streets
for i = 1:m
    
    if mod(i,2) ~= 0
        
        QInflowIndex( 2*i - 1 ) =  2*n*(i-1) + 1;
        QInflowIndex( 2*i ) = 2*n*(i-1) + 2;
        
    else
        
        QInflowIndex( 2*i - 1 ) = 2*n*i - 1;
        QInflowIndex( 2*i ) = 2*n*i;
        
    end
    
end

%loops over NS/SN streets
for i = 1:n
    
    if mod(i,2) ~= 0
        
        QInflowIndex( 2*m + 2*i - 1 ) =  M + 2*(i-1) + 1;
        QInflowIndex( 2*m + 2*i ) = M + 2*(i-1) + 2;
        
    else
        
        QInflowIndex( 2*m + 2*i ) = 2*M - 2*(n-i);
        QInflowIndex( 2*m + 2*i - 1 ) = 2*M - 2*(n-i) - 1;
        
    end
    
end
    
end