function varargout = graphgen(varargin)
% GRAPHGEN MATLAB code for graphgen.fig
%      GRAPHGEN, by itself, creates a new GRAPHGEN or raises the existing
%      singleton*.
%
%      H = GRAPHGEN returns the handle to a new GRAPHGEN or the handle to
%      the existing singleton*.
%
%      GRAPHGEN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GRAPHGEN.M with the given input arguments.
%
%      GRAPHGEN('Property','Value',...) creates a new GRAPHGEN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before graphgen_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to graphgen_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help graphgen

% Last Modified by GUIDE v2.5 30-Dec-2018 08:06:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @graphgen_OpeningFcn, ...
                   'gui_OutputFcn',  @graphgen_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before graphgen is made visible.
function graphgen_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to graphgen (see VARARGIN)

% Choose default command line output for graphgen
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes graphgen wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = graphgen_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function numvert_Callback(hObject, eventdata, handles)
% hObject    handle to numvert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numvert as text
%        str2double(get(hObject,'String')) returns contents of numvert as a double

%      N = str2double(get(handles.numvert,'String'));
%     %First select number of vertices.
%     %         axis off
%     % axis([-1.1,1.1,-1.1,1.1]);
%     hold on
%     for j=1:N %positioning and labelling N vertices
%         vertex= .95*[cos(j*2*pi/N),sin(j*2*pi/N)];
%         plot(vertex(1),vertex(2),'o','markersize',10)
%         name=.90*vertex;
%         text(name(1),name(2),int2str(j))
%     end

% --- Executes during object creation, after setting all properties.
function numvert_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numvert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in next.
function next_Callback(hObject, eventdata, handles)
% hObject    handle to next (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    global  quivertrack vertextrack adj
    %I know global variables are 'bad' but getting rid of them is
    %complicated (switching back and forth between functions) so this is on
    %hold otherwise I wont get anything else done
    quivertrack = []; vertextrack = [];

    cla;
    ginput_log = [];

    m = str2double(get(handles.enter_rows,'String'));
    n = str2double(get(handles.enter_columns,'String'));
    N = 4*m*n;
    StreetDim=[m,n];
    adj=zeros(N,N);
    
   
    axes(handles.vertpick);
    hold on
    handles.points = streetgrid_plot( [m,n], 1, 1 );

    x=2;
    y=2;
    righton1=0;
    righton2=0;
    
    handles.done = 0;
    guidata(hObject,handles);
    
    while ~(handles.done)
        
        [x,y]=ginput(2);
        ginput_log = cat(1,[x,y], ginput_log);
        
        for j=1:N
            if (abs(handles.points(j,1)-x(1))<1) && (abs(handles.points(j,2)-y(1))<1)
                x(1)=handles.points(j,1);
                y(1)=handles.points(j,2);
                righton1=1;
                vertex1=j;
            end
            
            if (abs(handles.points(j,1)-x(2))<1) && (abs(handles.points(j,2)-y(2))<1)
                x(2)=handles.points(j,1);
                y(2)=handles.points(j,2);
                righton2=1;
                vertex2=j;
            end
        end
        
        if (righton1==1)&&(righton2==1)

            tail=[x(1);y(1)];
            head=[x(2);y(2)];
            arrow=head-tail;
            
            last_arrow = quiver(x(1),y(1),arrow(1),arrow(2),0);
            quivertrack = cat(1,last_arrow, quivertrack);
            vertextrack = cat(1, [vertex2, vertex1,],vertextrack);
            adj(vertex2,vertex1)=1;
            
            righton1=0;
            righton2=0;

        end
        
          drawnow; %continuing the 'done' button components
          handles = guidata(hObject);
          
        end
        hold off
        handles.adj=adj;
        StreetDim;
        nrows=num2str(StreetDim(1));
        ncols=num2str(StreetDim(2));
        FileName=['adj_',nrows,'x',ncols,'_',datestr(now, 'mm-dd-yyyy_HH-MM'),'.mat'];
        save(FileName,'adj')
        disp(['Graph Matrix Saved on file ',FileName]);
        guidata(hObject,handles);
        
        
%         set(0,'showhiddenhandles','on'); % Make the GUI figure handle visible
%         h = findobj(gcf,'type','axes'); % Find the axes object in the GUI
%         f1 = figure; % Open a new figure with handle f1
%         s = copyobj(h,f1); % Copy axes object h into figure f1
        
        
% --- Executes on button press in done.
function done_Callback(hObject, eventdata, handles)
% hObject    handle to done (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    
    handles.done = 1;
    guidata(hObject,handles);


% --- Executes on button press in delete.
function delete_Callback(hObject, eventdata, handles)
% hObject    handle to delete (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global quivertrack vertextrack adj

    delete(quivertrack(1,1:end));
    adj(vertextrack(1,1), vertextrack(1,2)) = 0;
    vertextrack = vertextrack(2:end,:);
    quivertrack = quivertrack(2:end,:);
    
% --- Executes on selection change in graphselect.
function graphselect_Callback(hObject, eventdata, handles)
% hObject    handle to graphselect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns graphselect contents as cell array
%        contents{get(hObject,'Value')} returns selected item from graphselect

m = str2double(get(handles.enter_rows,'String'));
n = str2double(get(handles.enter_columns,'String'));
N = 4*m*n;

axes(handles.vertpick);
hold on

content = get(hObject, 'Value');

switch content
    
    case 2
        
        cla;
        [points] = streetgrid_plot( [m,n], 1, 1 );
        %adj = one_step(points,[m,n]);
        adj = one_step([m,n]);
        plot_graph(adj,points);
         
    case 3
        
        cla;
        [points] = streetgrid_plot( [m,n], 1, 1 );
        adj = one_step([m,n])^2;
        plot_graph(adj,points);

    case 4
        
        disp('Directed path')

    case 5

        disp('Undirected path')
        
    case 6

        cla;
        [points] = streetgrid_plot( [m,n], 1, 1 );
        adj = ones(N,N) - eye(N);
        plot_graph(adj,points);
        
    case 7
        
        cla;
        [points] = streetgrid_plot( [m,n], 1, 1 );
        adj = conflict([m,n]);
        plot_graph(adj,points);
        
    case 8
        
        cla;
        exit = exit_mat([m,n]);
        exitcat = cat(2,exit,zeros(m+n,m+n));
        points = streetgrid_plot( [m,n], 1, 1 );
        points = cat(1,points,zeros(m+n,2));
        spec = ':k'; lw = 1; pensize = 10;
        for i = 1:(m+n)
            
            points(N + i,:) = [10 + 5*i, 2];
            vertex = points(N+i,:);
            plot(vertex(1), vertex(2),spec,'markersize',pensize);
            
        end
        
        adj = cat(1, zeros(N,N+m+n), exitcat);
        plot_graph(adj,points);

    case 9
        
        cla
        [points] = streetgrid_plot( [m,n], 1, 1 );
        
    otherwise
        
end

%         set(0,'showhiddenhandles','on'); % Make the GUI figure handle visible
%         h = findobj(gcf,'type','axes'); % Find the axes object in the GUI
%         f1 = figure; % Open a new figure with handle f1
%         s = copyobj(h,f1); % Copy axes object h into figure f1
        

% --- Executes during object creation, after setting all properties.
function graphselect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to graphselect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    handles = guidata(hObject);
    set(hObject, 'min', 1);
    set(hObject, 'max', 15);
    sliderValue = floor(get(handles.slider1,'Value'));
    set(handles.disp_numvert,'String',num2str(sliderValue));

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in save_mat.
function save_mat_Callback(hObject, eventdata, handles)
% hObject    handle to save_mat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over popupmenu2.
function popupmenu2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over numvert.
function numvert_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to numvert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function enter_rows_Callback(hObject, eventdata, handles)
% hObject    handle to enter_rows (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_rows as text
%        str2double(get(hObject,'String')) returns contents of enter_rows as a double


% --- Executes during object creation, after setting all properties.
function enter_rows_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_rows (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function enter_columns_Callback(hObject, eventdata, handles)
% hObject    handle to enter_columns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_columns as text
%        str2double(get(hObject,'String')) returns contents of enter_columns as a double


% --- Executes during object creation, after setting all properties.
function enter_columns_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_columns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Wadjows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function done_CreateFcn(hObject, eventdata, handles)
% hObject    handle to done (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
