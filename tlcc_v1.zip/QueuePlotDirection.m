function [DirMat] = QueuePlotDirection( StreetDim )
%vectors of 1's and -1s indicating to draw a queue box left/right/up/down
%used in InitialQueue.m and UpdateQueue.m

m = StreetDim(1); n = StreetDim(2);

A1 = -1*toeplitz(mod(1:m,2),1);
B1 = toeplitz(mod(1:(m+1),2),1); B1 = B1(2:end);

AltMat1 = A1 + B1;
DirMat1 = kron(AltMat1,ones(2*n,1));

A2 = -1*toeplitz(mod(1:n,2),1);
B2 = toeplitz(mod(1:(n+1),2),1); B2 = B2(2:end);

AltMat2 = A2 + B2;
DirMat2 = repmat(kron(AltMat2,ones(2,1)),m,1);

DirMat = [DirMat1, DirMat2];

end