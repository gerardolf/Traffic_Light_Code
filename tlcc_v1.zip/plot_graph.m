function plot_graph(adj, vertex_mat )
%visualizes a graph based on adjacency matrix, with nodes' location
%specified by 'grid'. The nth row of 'grid' correspond to the nth vertice.

[to,from] = find( adj==1 );
k = length(to);

hold on

for i = 1:k
    
    tail = [vertex_mat(from(i),1), vertex_mat(from(i),2)];
    head = [vertex_mat(to(i),1), vertex_mat(to(i),2)];
    arrow = head-tail;
    quiver(tail(1),tail(2),arrow(1),arrow(2),0);
    
end

hold off