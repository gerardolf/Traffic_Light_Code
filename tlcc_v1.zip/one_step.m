function Af = one_step(street_dim)
%generates one-step matrix given street dimensions and a set of points

m = street_dim(1); n = street_dim(2);
N = 4*m*n; M = N/2;

%this splits up the vertices according to direction of streets
rw1 = ceil(m/2); rw2 = m - rw1;
cl1 = ceil(n/2); cl2 = n - cl1;
Af = zeros(N,N);

%this covers the WE streets
for i = 1:rw1
    
    %carefully selected indices that will be used to determine 'downstream'
    %connections later on
    row1_eve = ((i-1)*4*n+4):4:((2*n)+(i-1)*(4*n));
    row1_odd = ((i-1)*4*n+1):4:((2*n)+(i-1)*(4*n));
    T = length(row1_eve);
    S = length(row1_odd);
    
    for k = 1:T
        
        %turn lanes
        if i > 1 %stops if turns into an exit
            
            Af([M+row1_eve(k)-2*n,M+row1_eve(k)-2*n-1],row1_eve(k)-1)=1;
            
        end
        
        %through-lanes
        if 2*k < n %stops if continues into an exit
            
        Af([row1_eve(k)+1,row1_eve(k)+2],row1_eve(k))=1;
        
        end
        
        
    end
    
    for j = 1:S
        
        %turn-lanes
        if ( 1 + 2*(i-1) ) < m %stops if turns into an exit

            Af([M+row1_odd(j)+2*n,M+row1_odd(j)+1+2*n],row1_odd(j)+1)=1;
            
        end
        
        %through-lanes
        if ( 1 + 2*(j-1) ) < n %stops if continues into an exit
            
            Af([row1_odd(j)+2,row1_odd(j)+3],row1_odd(j))=1;
            
        end
        
    end
end

% this covers the EW streets
for i = 1:rw2
    
    row2_eve = (2*n+(i-1)*(4*n)+2):4:(i*(4*n));
    row2_odd = (2*n+(i-1)*(4*n)+3):4:(i*(4*n));
    T = length(row2_eve);
    S = length(row2_odd);
    
    for k = 1:T
                
        %turn-lanes
        if ( 2*i < m ) %stops if turns into an exit
            
            Af([M+row2_eve(k)+2*n,M+row2_eve(k)+2*n-1],row2_eve(k))=1;
            
        end
        
        %through-lanes
        if k > 1 %stops if continues into an exit
            
            Af([row2_eve(k)-2,row2_eve(k)-3],row2_eve(k)-1)=1;
            
        end
    end
    
    for j = 1:S
        
        Af([row2_odd(j)-1,row2_odd(j)-2],row2_odd(j)+1)=1;
        Af([M+1+row2_odd(j)-2*(n),M+row2_odd(j)-2*(n)],row2_odd(j))=1;
        
    end
end

% this covers the NS streets
for i = 1:cl1

    col1_eve = M+2 + 2*n + 4*(i-1):(4*n): (M+2 - 2*n + 2*m*n + 4*(i-1));
    col1_odd = M+1 + 4*(i-1):(4*n):(M+2 - 2*n + 2*m*n + 4*(i-1));
    T = length(col1_eve); S = length(col1_odd);
    
    for k = 1:T
        
        %turn-lanes
        if i > 1 %stops if turns into an exit
            
            Af([col1_eve(k)-2-M,col1_eve(k)-3-M],col1_eve(k)-1)=1;
            
        end
        
        %through-lanes
        if 2*k < m %stops if continues into an exit
            
        Af([col1_eve(k)+2*n,col1_eve(k)+2*n-1], col1_eve(k))=1;
        
        end
    end
    
    for j = 1:S
        
        %turn-lanes
        if ( (1+2*(i-1)) < n ) %stops if turns into an exit
            
            Af([col1_odd(j)-M+2,col1_odd(j)-M+3],col1_odd(j)+1)=1;
        
        end
        
        %through-lanes
        if ( (1+2*(j-1)) < m) %stops if contintues into an exit
 
        Af([col1_odd(j)+2*n,col1_odd(j)+2*n+1], col1_odd(j))=1;
 
        end
      
    end
end

% this covers the SN streets
for i = 1:cl2
    
    col2_eve = M+4+4*(i-1):(4*n):(M+4+4*(i-1)+(m-1)*2*n);
    col2_odd = M+3+2*n+4*(i-1):(4*n):(M+4+4*(i-1)+(m-1)*2*n);
    T = length(col2_eve); S = length(col2_odd);
    
    for k = 1:T
        
        %turn-lanes
        if 2*i < n %stops if turns into an exit
            
            Af([col2_eve(k)-M+1,col2_eve(k)-M+2],col2_eve(k)) = 1;
            
        end
        
        %through-lanes
        if k > 1 %stops if continues into an exit
        
            Af([col2_eve(k)-2*n,col2_eve(k)-2*n-1], col2_eve(k)-1)=1;

        end
    end
    
    for j = 1:S
        
        %turn-lanes
        Af([col2_odd(j)-M-2,col2_odd(j)-M-1],col2_odd(j)) = 1;
        %through-lanes
        Af([col2_odd(j)-2*n,col2_odd(j)-2*n+1], col2_odd(j)+1)=1;
 
    end
end
end