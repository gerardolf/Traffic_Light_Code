function Ac = SimpleConflict( StreetDim )

m = StreetDim(1); n = StreetDim(2); N = 4*m*n; M = N/2;
Ac = zeros( N, N );

for i = 1:2:M-1
    
    Ac( i + M, [i, i + 1] ) = 1;
    Ac( i + M + 1, [i, i + 1] ) = 1; 

end

Ac = Ac + Ac';