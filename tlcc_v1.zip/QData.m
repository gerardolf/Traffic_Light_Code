function [ QStart, X, Y ] = QData(NodePoints,QVec, DirMat)
%graph points indicates where the nodes are located. This will determine
%where the queue boxes begin. queue_prop will determine where the
%queueboxes end (how 'long' the box is)

gp = NodePoints;
qp = QVec;
[N,~] = size(gp); M = N/2;

%for testing use queue_prop = 1 + 3*rand(4*dim1*dim2,1), get graph_points
%from streetgrid_plot.m and make sure the 'hold on' 'hold off' lines are
%uncommented

DirMat1 = DirMat(:,1); DirMat2 = DirMat(:,2);

X11 = gp(1:M,1) + (-5)*DirMat1; X12 = X11 + qp(1:M).*DirMat1;
X21 = gp((M+1):end,1) - .5; X22 = gp((M+1):end,1) + .5;
X1 = cat(1, X11, X21); X2 = cat(1, X12, X22);

Y11 = gp(1:M,2) - .5; Y12 = gp(1:M,2) + .5;
Y21 = gp((M+1):end,2) + 5*DirMat2; Y22 = Y21 + (-1)*qp((M+1):end).*DirMat2;
Y1 = cat(1, Y11, Y21); Y2 = cat(1, Y12, Y22);

X = cat(2, X1, X2, X2, X1);
Y = cat(2, Y1, Y1, Y2, Y2);

QStart1 = cat(2, X11, Y11, Y12);
QStart2 = cat(2, X21, X22, Y21);
QStart = cat(1, QStart1, QStart2);

% h = fill(X',Y','b');

end