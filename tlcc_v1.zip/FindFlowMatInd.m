function FlowIndMat = FindFlowMatInd( street_dim, ComponentSwap )
%finds the indices to assign 1/3 or 2/3 to, which will then make the flow
%matrix columun stochastic

%this may be wrong, but what I did is assign 2/3 to an index if it itself
%is a turn (or through) lane with inflow from a turn (or through) lane,
%then assign 1/3 if it's inflow from a lane of a different type. This can
%easily be fixed by changing the 
%for now, CS(1) = 1/3 CS(2) = 2/3

m = street_dim(1); n = street_dim(2); CS = ComponentSwap;
N = 4*m*n; M = N/2;
FlowIndMat = zeros(2,N);

%this splits up the vertices according to direction of streets
rw1 = ceil(m/2); rw2 = m - rw1;
cl1 = ceil(n/2); cl2 = n - cl1;

%this covers the WE streets
for i = 1:rw1
    
    %carefully selected indices that will be used to determine 'downstream'
    %connections later on
    row1_eve = ((i-1)*4*n+4):4:((2*n)+(i-1)*(4*n));
    row1_odd = ((i-1)*4*n+1):4:((2*n)+(i-1)*(4*n));
    T = length(row1_eve);
    S = length(row1_odd);
    
    for k = 1:T
        
        %turn lanes
        if i > 1 %stops if turns into an exit
            
            FlowIndMat(1,row1_eve(k)-1) = CS(2);
            FlowIndMat(2,row1_eve(k)-1) = CS(1);
            
        end
        
        %through-lanes
        if 2*k < n %stops if continues into an exit
                    
        FlowIndMat(1,row1_eve(k)) = CS(2);
        FlowIndMat(2,row1_eve(k)) = CS(1);
        
        end

    end
    
    for j = 1:S
        
        %turn-lanes
        if ( 1 + 2*(i-1) ) < m %stops if turns into an exit

            FlowIndMat(1,row1_odd(j)+1) = CS(2);
            FlowIndMat(2,row1_odd(j)+1) = CS(1);
            
        end
        
        %through-lanes
        if ( 1 + 2*(j-1) ) < n %stops if continues into an exit
            
            FlowIndMat(1,row1_odd(j)) = CS(1);
            FlowIndMat(2,row1_odd(j)) = CS(2);
            
        end
        
    end
end

% this covers the EW streets
for i = 1:rw2
    
    row2_eve = (2*n+(i-1)*(4*n)+2):4:(i*(4*n));
    row2_odd = (2*n+(i-1)*(4*n)+3):4:(i*(4*n));
    T = length(row2_eve);
    S = length(row2_odd);
    
    for k = 1:T
                
        %turn-lanes
        if ( 2*i < m ) %stops if turns into an exit
            
            FlowIndMat(1,row2_eve(k)) = CS(1);
            FlowIndMat(2,row2_eve(k)) = CS(2);
            
        end
        
        %through-lanes
        if k > 1 %stops if continues into an exit
            
            FlowIndMat(1,row2_eve(k)-1) = CS(1);
            FlowIndMat(2,row2_eve(k)-1) = CS(2);
            
        end
    end
    
    for j = 1:S

        FlowIndMat(1,row2_odd(j)) = CS(1);
        FlowIndMat(2,row2_odd(j)) = CS(2);
        
        FlowIndMat(1,row2_odd(j)+1) = CS(2);
        FlowIndMat(2,row2_odd(j)+1) = CS(1);
        
    end
end

% this covers the NS streets
for i = 1:cl1

    col1_eve = M+2 + 2*n + 4*(i-1):(4*n): (M+2 - 2*n + 2*m*n + 4*(i-1));
    col1_odd = M+1 + 4*(i-1):(4*n):(M+2 - 2*n + 2*m*n + 4*(i-1));
    T = length(col1_eve); S = length(col1_odd);
    
    for k = 1:T
        
        %turn-lanes
        if i > 1 %stops if turns into an exit
            
            FlowIndMat(1,col1_eve(k)-1) = CS(2);
            FlowIndMat(2,col1_eve(k)-1) = CS(1);
            
        end
        
        %through-lanes
        if 2*k < m %stops if continues into an exit
            
            FlowIndMat(1,col1_eve(k)) = CS(2);
            FlowIndMat(2,col1_eve(k)) = CS(1);
            
        end
    end
    
    for j = 1:S
        
        %turn-lanes
        if ( (1+2*(i-1)) < n ) %stops if turns into an exit
            
            FlowIndMat(1,col1_odd(j)+1) = CS(2);
            FlowIndMat(2,col1_odd(j)+1) = CS(1);
        
        end
        
        %through-lanes
        if ( (1+2*(j-1)) < m) %stops if contintues into an exit
 
        FlowIndMat(1,col1_odd(j)) = CS(1);
        FlowIndMat(2,col1_odd(j)) = CS(2);
        
        end
      
    end
end

% this covers the SN streets
for i = 1:cl2
    
    col2_eve = M+4+4*(i-1):(4*n):(M+4+4*(i-1)+(m-1)*2*n);
    col2_odd = M+3+2*n+4*(i-1):(4*n):(M+4+4*(i-1)+(m-1)*2*n);
    T = length(col2_eve); S = length(col2_odd);
    
    for k = 1:T
        
        %turn-lanes
        if 2*i < n %stops if turns into an exit
            
            FlowIndMat(1,col2_eve(k)) = CS(1);
            FlowIndMat(2,col2_eve(k)) = CS(2);
            
        end
        
        %through-lanes
        if k > 1 %stops if continues into an exit
        
            FlowIndMat(1,col2_eve(k)-1) = CS(1);
            FlowIndMat(2,col2_eve(k)-1) = CS(2);

        end
    end
    
    for j = 1:S
        
        FlowIndMat(1,col2_odd(j)) = CS(1);
        FlowIndMat(2,col2_odd(j)) = CS(2);
        
        FlowIndMat(1,col2_odd(j)+1) = CS(2);
        FlowIndMat(2,col2_odd(j)+1) = CS(1);

    end
end

end