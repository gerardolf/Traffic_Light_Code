function [Astoc] = MakeStochastic( A, ComponentSwap )
%makes a matrix A column-stochastic (over non-zero columns), given the
%desired components of the already stochastic columns of ComponentSwap

[m,n] = size(ComponentSwap);
CompSwap = reshape(ComponentSwap,m*n,1); CS = CompSwap( CompSwap ~= 0 );

A( A~=0 ) = CS;
Astoc = A;

end