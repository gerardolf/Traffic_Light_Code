function plot_queue(graph_points,queue_prop,street_dim)
%graph points indicates where the nodes are located. This will determine
%where the queue boxes begin. queue_prop will determine where the
%queueboxes end (how 'long' the box is)

gp = graph_points;
qp = queue_prop;
[N,~] = size(gp); M = N/2;
dim1 = street_dim(1); dim2 = street_dim(2);

%for testing use queue_prop = 1 + 3*rand(4*dim1*dim2,1), get graph_points
%from streetgrid_plot.m and make sure the 'hold on' 'hold off' lines are
%uncommented

hold on
for i = 1:dim1
    
    for j = 1:(2*dim2)
        
        point = gp(j+(i-1)*(2*dim2),:);
        
        x_crd1 = point(1)+5*(-1)^(i+1); %fixes an edge of the box to the intersection
        x_crd2 = x_crd1 + qp(j+(i-1)*(2*dim2))*(-1)^i; %determines length of box
        y_crd1 = point(2) - .5;
        y_crd2 = point(2) + .5;
        
        fill([x_crd1 x_crd2 x_crd2 x_crd1],[y_crd1 y_crd1 y_crd2 y_crd2],'b');
        
    end
    
end

for i = 1:dim2
    
    for j = 1:dim1
        
        point1 = gp(M+1 + 2*(i-1) + (2*dim2)*(j-1),:);
        point2 = gp(M+1 + 2*(i-1) + (2*dim2)*(j-1) + 1,:);
        
        x_pt11 = point1(1) - .5;
        x_pt12 = point1(1) + .5;
        y_pt11 = point1(2) + 5*(-1)^i;
        y_pt12 = y_pt11 + qp(M+1 + 2*(i-1) + (2*dim2)*(j-1))*(-1)^(i+1);
        
        x_pt21 = point2(1) - .5;
        x_pt22 = point2(1) + .5;
        y_pt21 = point2(2) + 5*(-1)^i;
        y_pt22 = y_pt21 + qp(M+1 + 2*(i-1) + (2*dim2)*(j-1) + 1)*(-1)^(i+1);
       
        fill([x_pt11 x_pt12 x_pt12 x_pt11],[y_pt11 y_pt11 y_pt12 y_pt12],'b');
        fill([x_pt21 x_pt22 x_pt22 x_pt21],[y_pt21 y_pt21 y_pt22 y_pt22],'b');
        
    end
    
end
hold off

end