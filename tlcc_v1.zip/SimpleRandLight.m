function ColorVec = SimpleRandLight( StreetDim )

m = StreetDim(1);
n = StreetDim(2);
N = 4*m*n;
M = N/2;
CV = zeros(N,1);

for i = 1:2:M-1
    
    LightInd = randi([0,1]);
    
    CV([i, i+1]) = LightInd;
    
    if LightInd == 1
        
        CV([M + i, M + i+ 1]) = 0;
        
    else
        
        CV([M + i, M + i+ 1]) = 1;
        
    end

end

ColorVec = CV;